<!-- Developer guide: Home dashboard layout for import and NLP operations. -->
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${title}</title>
  <link rel="stylesheet" href="/css/app.css"/>
</head>
<body>
<header class="topbar">
  <h1>${title}</h1>
  <nav>
    <a href="/">Home</a>
    <a href="/protocols">Protocols</a>
    <a href="/speeches">Speeches</a>
    <a href="/analytics">Analytics</a>
    <a href="/export">Export</a>
    <a href="/swagger">Swagger</a>
  </nav>
</header>
<main class="container">
  <section class="card">
    <h2>System Stats</h2>
    <div id="stats-grid" class="stats-grid"></div>
  </section>
  <section class="card">
    <h2>Quick Actions</h2>
    <div id="import-status" class="import-status idle">No protocol import running.</div>
    <div class="actions">
      <button id="preview-import">Preview Import (period 20, limit 3)</button>
      <button id="run-import-3">Run Import (period 20, 3)</button>
      <button id="run-import-10">Run Import (period 20, 10)</button>
      <button id="run-import-all">Run Import (period 20, all)</button>
      <button id="run-nlp">Run NLP (limit 300)</button>
    </div>
    <div class="row wrap">
      <button id="import-nlp-file">Import Local NLP XMI Files</button>
    </div>
    <div id="nlp-import-status" class="import-status idle">No local NLP XMI import running.</div>
    <pre id="quick-output" class="output"></pre>
  </section>
  <section class="card">
    <h2>Video Candidate</h2>
    <p class="meta-note">Suggested protocol agenda items with multiple speeches from your imported data. This narrows the assignment's video task to one concrete case.</p>
    <div class="row wrap">
      <input id="video-protocol-id" placeholder="Protocol ID (e.g. 20-131)"/>
      <input id="video-agenda-item" placeholder="Agenda item (e.g. 7)"/>
    </div>
    <div class="row wrap">
      <input id="video-session-url" value="https://www.bundestag.de/mediathek/video?videoid=7649389" placeholder="Bundestag mediathek session URL"/>
      <input id="video-max-speeches" value="5" placeholder="Max speeches"/>
      <button id="auto-import-agenda-videos">Auto Import Agenda Videos</button>
      <button id="import-agenda-videos">Import Agenda Videos</button>
    </div>
    <div class="row wrap">
      <button id="refresh-video-candidates">Find Candidate</button>
    </div>
    <div id="video-candidate-status" class="import-status idle">No video candidate loaded.</div>
    <div id="video-candidate-list" class="list"></div>
  </section>
</main>
<script src="/js/index.js"></script>
</body>
</html>
