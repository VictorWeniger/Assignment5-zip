# Changes From Previous Task (3b)

Compared latest iteration `iter3` against latest iteration `iter3` from `3a`.

- Added files: 1
- Removed files: 0
- Modified files: 1

## Added
- `src/main/java/org/example/api/SpeechQueryFilterBuilder.java`

## Modified
- `CHANGES.md`
