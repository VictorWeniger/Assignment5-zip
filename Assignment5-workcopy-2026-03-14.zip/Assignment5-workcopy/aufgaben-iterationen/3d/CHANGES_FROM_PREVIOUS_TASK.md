# Changes From Previous Task (3d)

Compared latest iteration `iter5` against latest iteration `iter3` from `3c`.

- Added files: 16
- Removed files: 1
- Modified files: 11

## Added
- `CONSOLIDATION_NOTES.md`
- `LATEST_DUUI_SYNC_NOTE.md`
- `docs/CODE_WALKTHROUGH.md`
- `docs/DELIVERABLE_CHECKLIST.md`
- `docs/FINAL_REPORT.md`
- `docs/FULL_CODE_COMMENTARY.md`
- `docs/SLIDES_OUTLINE.md`
- `docs/SMOKE_TEST_RUNBOOK.md`
- `docs/USER_MANUAL.md`
- `src/main/java/org/example/service/nlp/DuuiComposerNlpEngine.java`
- `src/main/java/org/example/service/nlp/DuuiComposerPipeline.java`
- `src/main/resources/public/js/index.js`
- `src/main/resources/public/js/speech-detail.js`
- `src/main/resources/templates/index.ftl`
- `src/main/resources/templates/speech-detail.ftl`
- `src/test/java/org/example/service/NlpProcessingServiceTest.java`

## Removed
- `src/main/java/org/example/service/nlp/LocalHeuristicNlpEngine.java`

## Modified
- `CHANGES.md`
- `README.md`
- `docs/PROJECT_STATUS.md`
- `docs/planning/class-diagram.puml`
- `docs/planning/package-diagram.puml`
- `src/main/java/org/example/api/ProtocolController.java`
- `src/main/java/org/example/config/AppConfig.java`
- `src/main/java/org/example/config/NlpConfig.java`
- `src/main/java/org/example/service/NlpProcessingService.java`
- `src/main/java/org/example/service/nlp/NlpEngineSelector.java`
- `src/main/resources/public/js/analytics.js`
