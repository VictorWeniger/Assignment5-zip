# Changes From Previous Task (3c)

Compared latest iteration `iter3` against latest iteration `iter3` from `3b`.

- Added files: 2
- Removed files: 0
- Modified files: 1

## Added
- `src/main/resources/public/js/speeches.js`
- `src/main/resources/templates/speeches.ftl`

## Modified
- `CHANGES.md`
