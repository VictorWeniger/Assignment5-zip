package org.example.model;

/**
 * @author
 */

/**
 * Hält die Daten für Comment.
 */
public class Comment implements Identifiable {
    private String id;
    private String speechId;
    private String authorName;
    private String authorFaction;
    private int speechOffset;
    private String text;

    // Getter

@Override

    public String getId() {
        return id;
    }

    public String getSpeechId() {
        return speechId;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getAuthorFaction() {
        return authorFaction;
    }

    public int getSpeechOffset() {
        return speechOffset;
    }

    public String getText() {
        return text;
    }

    // Setter

/**
     * Setter
     */
    public void setId(String id) {
        this.id = id;
    }

    public void setSpeechId(String speechId) {
        this.speechId = speechId;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public void setAuthorFaction(String authorFaction) {
        this.authorFaction = authorFaction;
    }

    public void setSpeechOffset(int speechOffset) {
        this.speechOffset = speechOffset;
    }

    public void setText(String text) {
        this.text = text;
    }

}
