package org.example.model;

import java.util.Objects;

/**
 * @author
 */

/**
 * Hält die Daten für ParliamentaryGroup.
 */
public class ParliamentaryGroup implements Identifiable {
    private String id;
    private String shortName;
    private String displayName;

    // Getter

    @Override
    public String getId() {
        return id;
    }

    public String getShortName() {
        return shortName;
    }

    public String getDisplayName() {
        return displayName;
    }

    // Setter

    public void setId(String id) {
        this.id = id;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Constructor
     */
    public ParliamentaryGroup() {
    }

    /**
     * Constructor 2
     */
    public ParliamentaryGroup(String id, String shortName, String displayName) {
        this.id = id;
        this.shortName = shortName;
        this.displayName = displayName;
    }

    @Override
    // Gleichheit reicht hier über die ID, das spart später komische dopplungen in Sets.
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ParliamentaryGroup that = (ParliamentaryGroup) o;
        return Objects.equals(id, that.id);
    }

    @Override
    // Muss zur equals-Logik oben passen.
    public int hashCode() {
        return Objects.hash(id);
    }
}
