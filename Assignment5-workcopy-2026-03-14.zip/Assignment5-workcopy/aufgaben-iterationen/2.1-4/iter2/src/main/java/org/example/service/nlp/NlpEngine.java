package org.example.service.nlp;

import org.example.model.Speech;

/**
 * @author
 */

/**
 * Sammelt die Logik für NlpEngine.
 */
public interface NlpEngine {
    String name();

    boolean isAvailable();

    void annotate(Speech speech);
}
