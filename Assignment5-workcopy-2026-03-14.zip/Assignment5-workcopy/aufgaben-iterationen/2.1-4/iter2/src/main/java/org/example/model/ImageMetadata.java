package org.example.model;

/**
 * @author
 */

/**
 * Hält die Daten für ImageMetadata.
 */
public class ImageMetadata {
    private String sourceUrl;
    private String localPath;
    private String mimeType;
    private int width;
    private int height;
    private String copyrightNotice;

    // Getter

    public String getSourceUrl() {
        return sourceUrl;
    }

    public String getLocalPath() {
        return localPath;
    }

    public String getMimeType() {
        return mimeType;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public String getCopyrightNotice() {
        return copyrightNotice;
    }

    // Setter

    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    public void setLocalPath(String localPath) {
        this.localPath = localPath;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setCopyrightNotice(String copyrightNotice) {
        this.copyrightNotice = copyrightNotice;
    }

}
