package org.example.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author
 */

/**
 * Hält die Daten für Speech.
 */
public class Speech implements Identifiable {
    private String id;
    private String protocolId;
    private String sessionId;
    private int agendaItem;
    private Deputy speaker;
    private String text;
    private Instant startedAt;
    private Instant endedAt;
    private final List<Comment> comments = new ArrayList<>();
    private Map<String, Object> nlp = new HashMap<>();
    private List<Object> topics = new ArrayList<>();
    private Map<String, Integer> posDistribution = new HashMap<>();
    private List<Object> namedEntities = new ArrayList<>();
    private List<Double> sentenceSentiments = new ArrayList<>();
    private List<Double> sentiments = new ArrayList<>();
    private boolean nlpProcessed;
    private Instant nlpProcessedAt;

    // Getter

    @Override

    public String getId() {
        return id;
    }

    public String getProtocolId() {
        return protocolId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public int getAgendaItem() {
        return agendaItem;
    }

    public Deputy getSpeaker() {
        return speaker;
    }

    public String getText() {
        return text;
    }

    public Instant getStartedAt() {
        return startedAt;
    }

    public Instant getEndedAt() {
        return endedAt;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public Map<String, Object> getNlp() {
        return nlp;
    }

    public List<Object> getTopics() {
        return topics;
    }

    public Map<String, Integer> getPosDistribution() {
        return posDistribution;
    }

    public List<Object> getNamedEntities() {
        return namedEntities;
    }

    public List<Double> getSentenceSentiments() {
        return sentenceSentiments;
    }

    public List<Double> getSentiments() {
        return sentiments;
    }

    public boolean isNlpProcessed() {
        return nlpProcessed;
    }

    public Instant getNlpProcessedAt() {
        return nlpProcessedAt;
    }

    // Setter

    public void setId(String id) {
        this.id = id;
    }

    public void setProtocolId(String protocolId) {
        this.protocolId = protocolId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public void setAgendaItem(int agendaItem) {
        this.agendaItem = agendaItem;
    }

    public void setSpeaker(Deputy speaker) {
        this.speaker = speaker;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setStartedAt(Instant startedAt) {
        this.startedAt = startedAt;
    }

    public void setEndedAt(Instant endedAt) {
        this.endedAt = endedAt;
    }

    public void setNlp(Map<String, Object> nlp) {
        this.nlp = nlp;
    }

    public void setTopics(List<Object> topics) {
        this.topics = topics;
    }

    public void setPosDistribution(Map<String, Integer> posDistribution) {
        this.posDistribution = posDistribution;
    }

    public void setNamedEntities(List<Object> namedEntities) {
        this.namedEntities = namedEntities;
    }

    public void setSentenceSentiments(List<Double> sentenceSentiments) {
        this.sentenceSentiments = sentenceSentiments;
    }

    public void setSentiments(List<Double> sentiments) {
        this.sentiments = sentiments;
    }

    public void setNlpProcessed(boolean nlpProcessed) {
        this.nlpProcessed = nlpProcessed;
    }

    public void setNlpProcessedAt(Instant nlpProcessedAt) {
        this.nlpProcessedAt = nlpProcessedAt;
    }

}
