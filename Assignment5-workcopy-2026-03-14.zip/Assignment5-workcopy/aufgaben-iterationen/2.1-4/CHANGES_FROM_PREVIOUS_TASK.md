# Changes From Previous Task (2.1-4)

Compared latest iteration `iter3` against latest iteration `iter3` from `2.1-3`.

- Added files: 2
- Removed files: 0
- Modified files: 2

## Added
- `src/main/java/org/example/service/NlpAnnotationImportService.java`
- `src/main/java/org/example/service/nlp/UimaCasSerializer.java`

## Modified
- `CHANGES.md`
- `LATEST_DUUI_SYNC_NOTE.md`
