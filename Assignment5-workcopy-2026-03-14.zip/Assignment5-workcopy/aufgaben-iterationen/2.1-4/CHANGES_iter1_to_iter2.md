# Changes

Vergleich: `iter1` -> `iter2`

## Added Files
- `EXPERIMENT_NOTES.md`

## Removed Files
- (none)

## Modified Files
- `src/main/java/org/example/Application.java`

## Diff Stats
- 4 / 0: `/dev/null => aufgaben-iterationen/2.1-4/iter2/EXPERIMENT_NOTES.md`
- 5 / 0: `aufgaben-iterationen/2.1-4/{iter1 => iter2}/src/main/java/org/example/Application.java`
