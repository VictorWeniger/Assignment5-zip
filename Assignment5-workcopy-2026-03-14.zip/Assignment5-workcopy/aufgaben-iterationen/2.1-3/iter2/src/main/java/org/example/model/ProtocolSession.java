package org.example.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @author
 */

/**
 * Hält die Daten für ProtocolSession.
 */
public class ProtocolSession implements Identifiable {
    private String id;
    private String protocolId;
    private int legislativePeriod;
    private int sessionNumber;
    private LocalDate sessionDate;
    private final List<String> agenda = new ArrayList<>();
    private final List<String> speechIds = new ArrayList<>();

    // Getter
    @Override
    public String getId() {
        return id;
    }

    public String getProtocolId() {
        return protocolId;
    }

    public int getLegislativePeriod() {
        return legislativePeriod;
    }

    public int getSessionNumber() {
        return sessionNumber;
    }

    public LocalDate getSessionDate() {
        return sessionDate;
    }

    public List<String> getAgenda() {
        return agenda;
    }

    public List<String> getSpeechIds() {
        return speechIds;
    }

    // Setter
    public void setId(String id) {
        this.id = id;
    }

    public void setProtocolId(String protocolId) {
        this.protocolId = protocolId;
    }

    public void setLegislativePeriod(int legislativePeriod) {
        this.legislativePeriod = legislativePeriod;
    }

    public void setSessionNumber(int sessionNumber) {
        this.sessionNumber = sessionNumber;
    }

    public void setSessionDate(LocalDate sessionDate) {
        this.sessionDate = sessionDate;
    }

}
