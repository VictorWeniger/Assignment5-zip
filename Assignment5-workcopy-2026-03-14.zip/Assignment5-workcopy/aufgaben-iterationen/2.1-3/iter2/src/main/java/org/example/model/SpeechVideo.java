package org.example.model;

/**
 * @author
 */

/**
 * Hält die Daten für SpeechVideo.
 */
public class SpeechVideo implements Identifiable {
    private String id;
    private String speechId;
    private String sourceUrl;
    private String videoPageUrl;
    private String embedUrl;
    private String streamUrl;
    private String localPath;
    private int durationSeconds;

    // Getter
    @Override

    public String getId() {
        return id;
    }

    public String getSpeechId() {
        return speechId;
    }

    public String getSourceUrl() {
        return sourceUrl;
    }

    public String getVideoPageUrl() {
        return videoPageUrl;
    }

    public String getEmbedUrl() {
        return embedUrl;
    }

    public String getStreamUrl() {
        return streamUrl;
    }

    public String getLocalPath() {
        return localPath;
    }

    public int getDurationSeconds() {
        return durationSeconds;
    }

    // Setter
    public void setId(String id) {
        this.id = id;
    }

    public void setSpeechId(String speechId) {
        this.speechId = speechId;
    }

    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    public void setVideoPageUrl(String videoPageUrl) {
        this.videoPageUrl = videoPageUrl;
    }

    public void setEmbedUrl(String embedUrl) {
        this.embedUrl = embedUrl;
    }

    public void setStreamUrl(String streamUrl) {
        this.streamUrl = streamUrl;
    }

    public void setLocalPath(String localPath) {
        this.localPath = localPath;
    }

    public void setDurationSeconds(int durationSeconds) {
        this.durationSeconds = durationSeconds;
    }

}
