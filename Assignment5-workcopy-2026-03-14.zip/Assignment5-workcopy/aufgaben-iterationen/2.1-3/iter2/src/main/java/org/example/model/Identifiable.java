package org.example.model;

/**
 * @author
 */

/**
 * Datenmodell für Identifiable.
 */
public interface Identifiable {
    String getId();
}
