package org.example.config;

/**
 * @author
 */

/**
 * Konfiguration für NlpConfig.
 */
public class NlpConfig {

/**
 * Konfiguration für EngineMode.
 */
    public enum EngineMode {
        LOCAL,
        DUUI,
        AUTO
    }

    private final EngineMode engineMode;
    private final String duuiEndpoint;
    private final String duuiAuthToken;
    private final int duuiTimeoutSeconds;
    private final String duuiMode;
    private final int duuiWorkers;
    private final String duuiSpacyTarget;
    private final String duuiGervaderTarget;
    private final String duuiParlbertTopicTarget;
    private final String duuiSpacyLanguage;
    private final String duuiSelection;
    private final String duuiViewName;

    public NlpConfig(
            EngineMode engineMode,
            String duuiEndpoint,
            String duuiAuthToken,
            int duuiTimeoutSeconds,
            String duuiMode,
            int duuiWorkers,
            String duuiSpacyTarget,
            String duuiGervaderTarget,
            String duuiParlbertTopicTarget,
            String duuiSpacyLanguage,
            String duuiSelection,
            String duuiViewName
    ) {
        this.engineMode = engineMode;
        this.duuiEndpoint = duuiEndpoint;
        this.duuiAuthToken = duuiAuthToken;
        this.duuiTimeoutSeconds = duuiTimeoutSeconds;
        this.duuiMode = duuiMode;
        this.duuiWorkers = duuiWorkers;
        this.duuiSpacyTarget = duuiSpacyTarget;
        this.duuiGervaderTarget = duuiGervaderTarget;
        this.duuiParlbertTopicTarget = duuiParlbertTopicTarget;
        this.duuiSpacyLanguage = duuiSpacyLanguage;
        this.duuiSelection = duuiSelection;
        this.duuiViewName = duuiViewName;
    }

    public EngineMode engineMode() {
        return engineMode;
    }

    public String duuiEndpoint() {
        return duuiEndpoint;
    }

    public String duuiAuthToken() {
        return duuiAuthToken;
    }

    public int duuiTimeoutSeconds() {
        return duuiTimeoutSeconds;
    }

    public String duuiMode() {
        return duuiMode;
    }

    public int duuiWorkers() {
        return duuiWorkers;
    }

    public String duuiSpacyTarget() {
        return duuiSpacyTarget;
    }

    public String duuiGervaderTarget() {
        return duuiGervaderTarget;
    }

    public String duuiParlbertTopicTarget() {
        return duuiParlbertTopicTarget;
    }

    public String duuiSpacyLanguage() {
        return duuiSpacyLanguage;
    }

    public String duuiSelection() {
        return duuiSelection;
    }

    public String duuiViewName() {
        return duuiViewName;
    }

    public boolean hasDuuiEndpoint() {
        return duuiEndpoint != null && !duuiEndpoint.isBlank();
    }

    public boolean hasDuuiToken() {
        return duuiAuthToken != null && !duuiAuthToken.isBlank();
    }

    public boolean hasDuuiPipelineTargets() {
        return notBlank(duuiSpacyTarget)
                && notBlank(duuiGervaderTarget)
                && notBlank(duuiParlbertTopicTarget);
    }

    private static boolean notBlank(String value) {
        return value != null && !value.isBlank();
    }
}
