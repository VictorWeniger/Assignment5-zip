package org.example.model;

import java.time.Instant;

/**
 * @author
 */

/**
 * Hält die Daten für ProtocolDocument.
 */
public class ProtocolDocument implements Identifiable {
    private String id;
    private int legislativePeriod;
    private int sessionNumber;
    private String sourceUrl;
    private String rawXml;
    private Instant importedAt;

    // Getter

    @Override
    public String getId() {
        return id;
    }

    public int getLegislativePeriod() {
        return legislativePeriod;
    }

    public int getSessionNumber() {
        return sessionNumber;
    }

    public String getSourceUrl() {
        return sourceUrl;
    }

    public String getRawXml() {
        return rawXml;
    }

    public Instant getImportedAt() {
        return importedAt;
    }

    // Setter

    public void setId(String id) {
        this.id = id;
    }

    public void setLegislativePeriod(int legislativePeriod) {
        this.legislativePeriod = legislativePeriod;
    }

    public void setSessionNumber(int sessionNumber) {
        this.sessionNumber = sessionNumber;
    }

    public void setSourceUrl(String sourceUrl) {
        this.sourceUrl = sourceUrl;
    }

    public void setRawXml(String rawXml) {
        this.rawXml = rawXml;
    }


    public void setImportedAt(Instant importedAt) {
        this.importedAt = importedAt;
    }
}
