package org.example.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @author
 */

/**
 * Hält die Daten für Deputy.
 */
public class Deputy implements Identifiable {
    private String id;
    private String firstName;
    private String lastName;
    private String title;
    private LocalDate birthDate;
    private String birthPlace;
    private String birthCountry;
    private LocalDate deathDate;
    private String gender;
    private String maritalStatus;
    private String religion;
    private String profession;
    private String partyShort;
    private String vitaShort;
    private String publicationRequiredInfo;
    private ParliamentaryGroup parliamentaryGroup;
    private DeputyRole role = DeputyRole.DEPUTY;
    private final List<DeputyLegislativePeriod> legislativePeriods = new ArrayList<>();
    private final List<ImageMetadata> images = new ArrayList<>();

    // Getter

    @Override
    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getTitle() {
        return title;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public String getBirthPlace() {
        return birthPlace;
    }

    public String getBirthCountry() {
        return birthCountry;
    }

    public LocalDate getDeathDate() {
        return deathDate;
    }

    public String getGender() {
        return gender;
    }

    public String getMaritalStatus() {
        return maritalStatus;
    }

    public String getReligion() {
        return religion;
    }

    public String getProfession() {
        return profession;
    }

    public String getPartyShort() {
        return partyShort;
    }

    public String getVitaShort() {
        return vitaShort;
    }

    public String getPublicationRequiredInfo() {
        return publicationRequiredInfo;
    }

    public ParliamentaryGroup getParliamentaryGroup() {
        return parliamentaryGroup;
    }

    public DeputyRole getRole() {
        return role;
    }

    public List<DeputyLegislativePeriod> getLegislativePeriods() {
        return legislativePeriods;
    }

    public List<ImageMetadata> getImages() {
        return images;
    }

    // Setter

public void setId(String id) {
        this.id = id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public void setBirthPlace(String birthPlace) {
        this.birthPlace = birthPlace;
    }

    public void setBirthCountry(String birthCountry) {
        this.birthCountry = birthCountry;
    }

    public void setDeathDate(LocalDate deathDate) {
        this.deathDate = deathDate;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public void setPartyShort(String partyShort) {
        this.partyShort = partyShort;
    }

    public void setVitaShort(String vitaShort) {
        this.vitaShort = vitaShort;
    }

    public void setPublicationRequiredInfo(String publicationRequiredInfo) {
        this.publicationRequiredInfo = publicationRequiredInfo;
    }

    public void setParliamentaryGroup(ParliamentaryGroup parliamentaryGroup) {
        this.parliamentaryGroup = parliamentaryGroup;
    }

    public void setRole(DeputyRole role) {
        this.role = role;
    }

}
