package org.example.config;

/**
 * @author
 */

/**
 * Zieht die Einstellungen für NlpConfig zusammen.
 */
public class NlpConfig {
    // Die Modi sind hier klein gehalten, damit die Auswahl in der App simpel bleibt.
    public enum EngineMode {
        DUUI,
        AUTO
    }

    private final EngineMode engineMode;
    private final String duuiEndpoint;
    private final String duuiAuthToken;
    private final int duuiTimeoutSeconds;
    private final String duuiMode;
    private final int duuiWorkers;
    private final String duuiSpacyTarget;
    private final String duuiGervaderTarget;
    private final String duuiParlbertTopicTarget;
    private final String duuiSpacyLanguage;
    private final String duuiSelection;
    private final String duuiViewName;

    public NlpConfig(
            EngineMode engineMode,
            String duuiEndpoint,
            String duuiAuthToken,
            int duuiTimeoutSeconds,
            String duuiMode,
            int duuiWorkers,
            String duuiSpacyTarget,
            String duuiGervaderTarget,
            String duuiParlbertTopicTarget,
            String duuiSpacyLanguage,
            String duuiSelection,
            String duuiViewName
    ) {
        this.engineMode = engineMode;
        this.duuiEndpoint = duuiEndpoint;
        this.duuiAuthToken = duuiAuthToken;
        this.duuiTimeoutSeconds = duuiTimeoutSeconds;
        this.duuiMode = duuiMode;
        this.duuiWorkers = duuiWorkers;
        this.duuiSpacyTarget = duuiSpacyTarget;
        this.duuiGervaderTarget = duuiGervaderTarget;
        this.duuiParlbertTopicTarget = duuiParlbertTopicTarget;
        this.duuiSpacyLanguage = duuiSpacyLanguage;
        this.duuiSelection = duuiSelection;
        this.duuiViewName = duuiViewName;
    }

    public EngineMode engineMode() {
        return engineMode;
    }

    public String duuiEndpoint() {
        return duuiEndpoint;
    }

    public String duuiAuthToken() {
        return duuiAuthToken;
    }

    public int duuiTimeoutSeconds() {
        return duuiTimeoutSeconds;
    }

    public String duuiMode() {
        return duuiMode;
    }

    public int duuiWorkers() {
        return duuiWorkers;
    }

    public String duuiSpacyTarget() {
        return duuiSpacyTarget;
    }

    public String duuiGervaderTarget() {
        return duuiGervaderTarget;
    }

    public String duuiParlbertTopicTarget() {
        return duuiParlbertTopicTarget;
    }

    public String duuiSpacyLanguage() {
        return duuiSpacyLanguage;
    }

    public String duuiSelection() {
        return duuiSelection;
    }

    public String duuiViewName() {
        return duuiViewName;
    }

    //  Remote-Weg.
    public boolean hasDuuiEndpoint() {
        return duuiEndpoint != null && !duuiEndpoint.isBlank();
    }

    public boolean hasDuuiToken() {
        return duuiAuthToken != null && !duuiAuthToken.isBlank();
    }

    // Für den Composer müssen alle drei Ziele gesetzt sein.
    public boolean hasDuuiPipelineTargets() {
        return notBlank(duuiSpacyTarget)
                && notBlank(duuiGervaderTarget)
                && notBlank(duuiParlbertTopicTarget);
    }

    //----helper---
    private static boolean notBlank(String value) {
        return value != null && !value.isBlank();
    }
}
