package org.example.config;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * @author
 */

/**
 * Zieht die Einstellungen für CredentialsFileLoader zusammen.
 */
public final class CredentialsFileLoader {
    private CredentialsFileLoader() {
    }

    // Lädt die Properties-Datei, wenn es sie gibt. Sonst leer
    public static Properties load(String path) {
        Properties props = new Properties();
        if (path == null || path.isBlank()) {
            return props;
        }

        Path p = Path.of(path);
        if (!Files.exists(p)) {
            return props;
        }

        try (InputStream in = Files.newInputStream(p)) {
            props.load(in);
        } catch (IOException ignored) {
            // hier einfach still versuchen und notfalls weiter.
        }
        return props;
    }
}
