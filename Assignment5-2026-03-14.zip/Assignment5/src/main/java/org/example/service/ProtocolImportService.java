package org.example.service;

import org.example.db.DatabaseHandler;
import org.example.model.Deputy;
import org.example.model.ImageMetadata;
import org.example.model.ParliamentaryGroup;
import org.example.model.ProtocolDocument;
import org.example.model.ProtocolSession;
import org.example.model.Speech;
import org.example.model.SpeechVideo;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

/**
 * @author
 */

/**
 * Sammelt die Logik für ProtocolImportService.
 */
public class ProtocolImportService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProtocolImportService.class);

    private final BundestagProtocolDownloader downloader;
    private final DatabaseHandler<ProtocolDocument> protocolDatabase;
    private final DatabaseHandler<ProtocolSession> sessionDatabase;
    private final DatabaseHandler<Speech> speechDatabase;
    private final DatabaseHandler<Deputy> deputyDatabase;
    private final DatabaseHandler<SpeechVideo> speechVideoDatabase;
    private final DeputyImageEnrichmentService deputyImageEnrichmentService;
    private final MediaAssetDownloadService mediaAssetDownloadService;
    private final DeputyMasterDataImportService deputyMasterDataImportService;
    private final AgendaVideoImportService agendaVideoImportService;
    private final XmlProtocolParser parser;
    private final AtomicBoolean importRunning = new AtomicBoolean(false);

/**
 * Constructor
 */
    public ProtocolImportService(
            BundestagProtocolDownloader downloader,
            DatabaseHandler<ProtocolDocument> protocolDatabase,
            DatabaseHandler<ProtocolSession> sessionDatabase,
            DatabaseHandler<Speech> speechDatabase,
            DatabaseHandler<Deputy> deputyDatabase,
            DatabaseHandler<SpeechVideo> speechVideoDatabase,
            DeputyImageEnrichmentService deputyImageEnrichmentService,
            MediaAssetDownloadService mediaAssetDownloadService,
            DeputyMasterDataImportService deputyMasterDataImportService,
            AgendaVideoImportService agendaVideoImportService,
            XmlProtocolParser parser
    ) {
        this.downloader = downloader;
        this.protocolDatabase = protocolDatabase;
        this.sessionDatabase = sessionDatabase;
        this.speechDatabase = speechDatabase;
        this.deputyDatabase = deputyDatabase;
        this.speechVideoDatabase = speechVideoDatabase;
        this.deputyImageEnrichmentService = deputyImageEnrichmentService;
        this.mediaAssetDownloadService = mediaAssetDownloadService;
        this.deputyMasterDataImportService = deputyMasterDataImportService;
        this.agendaVideoImportService = agendaVideoImportService;
        this.parser = parser;
    }

    // Nimmt einfach die Standard-Optionen und stößt damit den normalen Import an.
    public ImportSummary importMissingProtocols() {
        return importProtocols(ImportOptions.defaultOptions());
    }

    // Baut nur eine Vorschau, damit man vor dem eigentlichen Lauf sieht, was drankäme.
    public List<ImportCandidate> previewImportCandidates(ImportOptions options) {
        try {
            List<String> discoveredLinks = downloader.fetchProtocolXmlLinks();
            LOGGER.info("Discovered {} raw protocol XML links for preview", discoveredLinks.size());
            List<String> xmlLinks = filterLinks(discoveredLinks, options);
            LOGGER.info("Preview retained {} protocol XML links after filtering", xmlLinks.size());
            return xmlLinks.stream().map(link -> {
                try {
                    ProtocolIdParser.ParsedProtocolId parsed = ProtocolIdParser.parse(link);
                    boolean exists = protocolDatabase.count("protocols", new Document("id",
                            parsed.protocolId())) > 0;
                    return new ImportCandidate(parsed.protocolId(), parsed.legislativePeriod(), parsed.sessionNumber(),
                            link, exists);
                } catch (IllegalArgumentException ex) {
                    return null;
                }
            }).filter(candidate -> candidate != null).collect(Collectors.toList());
        } catch (IOException e) {
            LOGGER.error("Could not preview import candidates", e);
            return List.of();
        }
    }

    // Zieht genau ein Protokoll rein und hält dabei die Import-Sperre sauber fest.
    public ImportSummary importSingleProtocol(String protocolId, boolean forceReimportExisting) {
        if (!importRunning.compareAndSet(false, true)) {
            throw new IllegalStateException("A protocol import is already running");
        }
        try {
            List<String> xmlLinks = downloader.fetchProtocolXmlLinks();
            LOGGER.info("Discovered {} raw protocol XML links for single import {}", xmlLinks.size(), protocolId);
            for (String xmlLink : xmlLinks) {
                ProtocolIdParser.ParsedProtocolId parsed;
                try {
                    parsed = ProtocolIdParser.parse(xmlLink);
                } catch (IllegalArgumentException ex) {
                    continue;
                }

                if (!parsed.protocolId().equals(protocolId)) {
                    continue;
                }

                ImportOptions options = new ImportOptions(parsed.legislativePeriod(), 1,
                        forceReimportExisting);
                return importProtocolsWithFixedLinks(options, List.of(xmlLink));
            }
            return new ImportSummary(0, 0, 0, 0, 0, 0, 0, 0, 0);
        } catch (IOException e) {
            LOGGER.error("Could not import single protocol {}", protocolId, e);
            return new ImportSummary(0, 0, 0, 0, 0, 0, 0, 0, 0);
        } finally {
            importRunning.set(false);
        }
    }

    // Das ist der normale Batch-Einstieg für den Import über Wahlperiode und Limit.
    public ImportSummary importProtocols(ImportOptions options) {
        if (!importRunning.compareAndSet(false, true)) {
            throw new IllegalStateException("A protocol import is already running");
        }
        try {
            List<String> discoveredLinks = downloader.fetchProtocolXmlLinks();
            LOGGER.info("Discovered {} raw protocol XML links for import", discoveredLinks.size());
            List<String> xmlLinks = prefilterExistingProtocols(filterLinks(discoveredLinks, options), options);
            LOGGER.info(
                    "Import retained {} protocol XML links after filtering (period={}, limit={}, force={})",
                    xmlLinks.size(),
                    options.legislativePeriodFilter(),
                    options.maxProtocols(),
                    options.forceReimportExisting()
            );
            if (xmlLinks.isEmpty()) {
                LOGGER.warn("No protocol XML links available for import after discovery/filtering");
            }
            return importProtocolsWithFixedLinks(options, xmlLinks);
        } catch (IOException e) {
            LOGGER.error("Protocol import failed", e);
            return new ImportSummary(0, 0, 0, 0, 0, 0, 0, 0, 0);
        } finally {
            importRunning.set(false);
        }
    }

    //----helper---
    // Wirft schon bekannte Protokolle vorher raus, damit nicht unnötig gezogen wird.
    private List<String> prefilterExistingProtocols(List<String> xmlLinks, ImportOptions options) {
        if (options.forceReimportExisting() || xmlLinks.isEmpty()) {
            return xmlLinks;
        }

        Set<String> existingProtocolIds = protocolDatabase.find("protocols", new Document(), ProtocolDocument
                        .class).stream()
                .map(ProtocolDocument::getId)
                .filter(id -> id != null && !id.isBlank())
                .collect(Collectors.toCollection(LinkedHashSet::new));

        if (existingProtocolIds.isEmpty()) {
            return xmlLinks;
        }

        List<String> filtered = xmlLinks.stream()
                .filter(link -> {
                    try {
                        return !existingProtocolIds.contains(ProtocolIdParser.parse(link).protocolId());
                    } catch (IllegalArgumentException ex) {
                        return false;
                    }
                })
                .toList();

        int skippedExisting = xmlLinks.size() - filtered.size();
        if (skippedExisting > 0) {
            LOGGER.info("Prefilter skipped {} already imported protocol links before download", skippedExisting);
        }
        return filtered;
    }

    // Arbeitet die schon gefundenen XML-Links wirklich ab und schreibt alles in die DB.
    private ImportSummary importProtocolsWithFixedLinks(ImportOptions options, List<String> xmlLinks) {
        int importedProtocols = 0;
        int upsertedSessions = 0;
        int upsertedSpeeches = 0;
        int upsertedDeputies = 0;
        int upsertedVideos = 0;
        int enrichedDeputyImages = 0;
        int skippedInvalidSpeeches = 0;
        int skippedInvalidDeputies = 0;
        int skippedInvalidVideos = 0;
        Set<Integer> importedDeputyPeriods = new LinkedHashSet<>();

        for (String xmlLink : xmlLinks) {
            ProtocolIdParser.ParsedProtocolId parsedId;
            try {
                parsedId = ProtocolIdParser.parse(xmlLink);
            } catch (IllegalArgumentException ex) {
                LOGGER.debug("Skipping URL without parseable protocol id: {}", xmlLink);
                continue;
            }

            boolean exists = protocolDatabase.count("protocols", new Document("id", parsedId.protocolId())) > 0;
            if (exists && !options.forceReimportExisting()) {
                continue;
            }

            if (importedDeputyPeriods.add(parsedId.legislativePeriod())) {
                DeputyMasterDataImportService.ImportResult deputyImportResult =
                        deputyMasterDataImportService.importLegislativePeriod(
                                parsedId.legislativePeriod(),
                                deputyDatabase,
                                deputyImageEnrichmentService,
                                mediaAssetDownloadService
                        );
                LOGGER.info(
                        "Imported deputy master data for legislative period {} (matched={}, upserted={}, imageAttempts={})",
                        deputyImportResult.legislativePeriod(),
                        deputyImportResult.matchedDeputies(),
                        deputyImportResult.upsertedDeputies(),
                        deputyImportResult.imageAttempts()
                );
            }

            String xml;
            try {
                xml = downloader.downloadXml(xmlLink);
            } catch (IOException e) {
                LOGGER.error("Failed to download xml for {}", xmlLink, e);
                continue;
            }
            ProtocolDocument protocol = new ProtocolDocument();
            protocol.setId(parsedId.protocolId());
            protocol.setLegislativePeriod(parsedId.legislativePeriod());
            protocol.setSessionNumber(parsedId.sessionNumber());
            protocol.setSourceUrl(xmlLink);
            protocol.setRawXml(xml);
            protocol.setImportedAt(Instant.now());
            protocolDatabase.replaceById("protocols", protocol.getId(), protocol);
            importedProtocols++;

            XmlProtocolParser.ParsedProtocol parsedProtocol = parser.parse(
                    parsedId.protocolId(),
                    parsedId.legislativePeriod(),
                    xml
            );
            ValidationResult validationResult = validateParsedProtocol(
                    parsedProtocol,
                    parsedId.protocolId(),
                    parsedId.legislativePeriod()
            );

            sessionDatabase.replaceById("sessions", validationResult.session().getId(), validationResult
                    .session());
            upsertedSessions++;

            for (Speech speech : validationResult.speeches()) {
                speechDatabase.replaceById("speeches", speech.getId(), speech);
                upsertedSpeeches++;
            }
            skippedInvalidSpeeches += validationResult.invalidSpeechCount();

            for (Deputy deputy : validationResult.deputies()) {
                deputyImageEnrichmentService.enrichWithProfileImage(deputy);
                for (ImageMetadata image : deputy.getImages()) {
                    mediaAssetDownloadService.downloadDeputyImage(image, deputy.getId());
                    enrichedDeputyImages++;
                }

                deputyDatabase.replaceById("deputies", deputy.getId(), deputy);
                upsertedDeputies++;
            }
            skippedInvalidDeputies += validationResult.invalidDeputyCount();

            for (SpeechVideo speechVideo : validationResult.videos()) {
                mediaAssetDownloadService.downloadSpeechVideo(speechVideo);
                speechVideoDatabase.replaceById("speech_videos", speechVideo.getId(), speechVideo);
                upsertedVideos++;
            }
            upsertedVideos += backfillMissingSpeechVideos(validationResult.speeches());
            skippedInvalidVideos += validationResult.invalidVideoCount();
        }

        return new ImportSummary(
                importedProtocols,
                upsertedSessions,
                upsertedSpeeches,
                upsertedDeputies,
                upsertedVideos,
                enrichedDeputyImages,
                skippedInvalidSpeeches,
                skippedInvalidDeputies,
                skippedInvalidVideos
        );
    }

    private ValidationResult validateParsedProtocol(
            XmlProtocolParser.ParsedProtocol parsedProtocol,
            String protocolId,
            int legislativePeriod
    ) {
        ProtocolSession session = parsedProtocol.session();
        if (session.getId() == null || session.getId().isBlank()) {
            session.setId("session-" + protocolId);
        }
        if (session.getProtocolId() == null || session.getProtocolId().isBlank()) {
            session.setProtocolId(protocolId);
        }

        List<Speech> validSpeeches = parsedProtocol.speeches().stream()
                .filter(speech -> speech != null && speech.getId() != null && !speech.getId().isBlank())
                .peek(speech -> {
                    if (speech.getProtocolId() == null || speech.getProtocolId().isBlank()) {
                        speech.setProtocolId(protocolId);
                    }
                    if (speech.getSessionId() == null || speech.getSessionId().isBlank()) {
                        speech.setSessionId(session.getId());
                    }
                    if (speech.getText() == null) {
                        speech.setText("");
                    }
                    speech.setSpeaker(resolveDeputyProfile(speech.getSpeaker(), legislativePeriod));
                })
                .collect(Collectors.toList());
        int invalidSpeechCount = parsedProtocol.speeches().size() - validSpeeches.size();

        List<Deputy> validDeputies = parsedProtocol.deputies().stream()
                .filter(deputy -> deputy != null && deputy.getId() != null && !deputy.getId().isBlank())
                .map(deputy -> resolveDeputyProfile(deputy, legislativePeriod))
                .collect(Collectors.toList());
        int invalidDeputyCount = parsedProtocol.deputies().size() - validDeputies.size();

        Set<String> validSpeechIds = new HashSet<>();
        for (Speech speech : validSpeeches) {
            validSpeechIds.add(speech.getId());
        }
        List<SpeechVideo> validVideos = parsedProtocol.videos().stream()
                .filter(video -> video != null
                        && video.getId() != null
                        && !video.getId().isBlank()
                        && video.getSpeechId() != null
                        && validSpeechIds.contains(video.getSpeechId())
                        && video.getSourceUrl() != null
                        && !video.getSourceUrl().isBlank())
                .collect(Collectors.toList());
        int invalidVideoCount = parsedProtocol.videos().size() - validVideos.size();

        return new ValidationResult(
                session,
                validSpeeches,
                validDeputies,
                validVideos,
                invalidSpeechCount,
                invalidDeputyCount,
                invalidVideoCount
        );
    }

    private Deputy resolveDeputyProfile(Deputy parsedDeputy, int legislativePeriod) {
        if (parsedDeputy == null || parsedDeputy.getId() == null || parsedDeputy.getId().isBlank()) {
            return parsedDeputy;
        }
        Deputy stored = deputyDatabase.findById("deputies", parsedDeputy.getId(), Deputy.class).orElse(null);
        if (stored == null) {
            return parsedDeputy;
        }
        return mergeDeputies(stored, parsedDeputy, legislativePeriod);
    }

    private Deputy mergeDeputies(Deputy baseDeputy, Deputy overlayDeputy, int legislativePeriod) {
        Deputy merged = new Deputy();
        merged.setId(firstNonBlank(overlayDeputy.getId(), baseDeputy.getId()));
        merged.setFirstName(firstNonBlank(baseDeputy.getFirstName(), overlayDeputy.getFirstName()));
        merged.setLastName(firstNonBlank(baseDeputy.getLastName(), overlayDeputy.getLastName()));
        merged.setTitle(firstNonBlank(baseDeputy.getTitle(), overlayDeputy.getTitle()));
        merged.setBirthDate(baseDeputy.getBirthDate() != null ? baseDeputy.getBirthDate() : overlayDeputy.getBirthDate());
        merged.setBirthPlace(firstNonBlank(baseDeputy.getBirthPlace(), overlayDeputy.getBirthPlace()));
        merged.setBirthCountry(firstNonBlank(baseDeputy.getBirthCountry(), overlayDeputy.getBirthCountry()));
        merged.setDeathDate(baseDeputy.getDeathDate() != null ? baseDeputy.getDeathDate() : overlayDeputy.getDeathDate());
        merged.setGender(firstNonBlank(baseDeputy.getGender(), overlayDeputy.getGender()));
        merged.setMaritalStatus(firstNonBlank(baseDeputy.getMaritalStatus(), overlayDeputy.getMaritalStatus()));
        merged.setReligion(firstNonBlank(baseDeputy.getReligion(), overlayDeputy.getReligion()));
        merged.setProfession(firstNonBlank(baseDeputy.getProfession(), overlayDeputy.getProfession()));
        merged.setPartyShort(firstNonBlank(baseDeputy.getPartyShort(), overlayDeputy.getPartyShort()));
        merged.setVitaShort(firstNonBlank(baseDeputy.getVitaShort(), overlayDeputy.getVitaShort()));
        merged.setPublicationRequiredInfo(firstNonBlank(
                baseDeputy.getPublicationRequiredInfo(),
                overlayDeputy.getPublicationRequiredInfo()
        ));
        merged.setRole(overlayDeputy.getRole() != null ? overlayDeputy.getRole() : baseDeputy.getRole());
        merged.setParliamentaryGroup(selectParliamentaryGroup(baseDeputy, overlayDeputy, legislativePeriod));
        merged.getLegislativePeriods().addAll(baseDeputy.getLegislativePeriods());
        for (var period : overlayDeputy.getLegislativePeriods()) {
            boolean known = merged.getLegislativePeriods().stream()
                    .anyMatch(existing -> existing != null
                            && period != null
                            && existing.getLegislativePeriod() == period.getLegislativePeriod());
            if (!known) {
                merged.getLegislativePeriods().add(period);
            }
        }
        if (merged.getImages().isEmpty()) {
            merged.getImages().addAll(baseDeputy.getImages());
        }
        if (merged.getImages().isEmpty()) {
            merged.getImages().addAll(overlayDeputy.getImages());
        }
        return merged;
    }

    private ParliamentaryGroup selectParliamentaryGroup(Deputy baseDeputy, Deputy overlayDeputy, int legislativePeriod) {
        if (baseDeputy.getParliamentaryGroup() != null) {
            boolean periodKnown = baseDeputy.getLegislativePeriods().stream()
                    .anyMatch(period -> period != null && period.getLegislativePeriod() ==
                            legislativePeriod);
            if (periodKnown) {
                return baseDeputy.getParliamentaryGroup();
            }
        }
        return overlayDeputy.getParliamentaryGroup() != null
                ? overlayDeputy.getParliamentaryGroup()
                : baseDeputy.getParliamentaryGroup();
    }

    private int backfillMissingSpeechVideos(List<Speech> speeches) {
        int upserted = 0;
        for (Speech speech : speeches) {
            if (speech == null || speech.getId() == null || speech.getId().isBlank()) {
                continue;
            }
            boolean alreadyStored = speechVideoDatabase.findById("speech_videos", "video-" + speech.getId(),
                    SpeechVideo.class).isPresent();
            if (alreadyStored) {
                continue;
            }
            try {
                agendaVideoImportService.importVideosForSpeech(speech.getId());
                SpeechVideo imported = speechVideoDatabase.findById("speech_videos", "video-" +
                                speech.getId(), SpeechVideo.class)
                        .orElse(null);
                if (imported == null) {
                    continue;
                }
                mediaAssetDownloadService.downloadSpeechVideo(imported);
                speechVideoDatabase.replaceById("speech_videos", imported.getId(), imported);
                upserted++;
            } catch (IllegalArgumentException ignored) {
            }
        }
        return upserted;
    }

    private String firstNonBlank(String primary, String fallback) {
        if (primary != null && !primary.isBlank()) {
            return primary;
        }
        return fallback;
    }

    private List<String> filterLinks(List<String> xmlLinks, ImportOptions options) {
        List<String> filtered = xmlLinks.stream()
                .filter(link -> {
                    if (options.legislativePeriodFilter() == null) {
                        return true;
                    }
                    try {
                        ProtocolIdParser.ParsedProtocolId id = ProtocolIdParser.parse(link);
                        return id.legislativePeriod() == options.legislativePeriodFilter();
                    } catch (IllegalArgumentException ex) {
                        return false;
                    }
                })
                .sorted(Comparator.naturalOrder())
                .collect(Collectors.toList());

        if (options.legislativePeriodFilter() != null && filtered.isEmpty()) {
            LOGGER.warn(
                    "No protocol XML links matched legislative period {}. Sample discovered links: {}",
                    options.legislativePeriodFilter(),
                    xmlLinks.stream().limit(5).collect(Collectors.toList())
            );
        }

        if (options.maxProtocols() > 0 && filtered.size() > options.maxProtocols()) {
            return filtered.subList(0, options.maxProtocols());
        }
        return filtered;
    }

/**
 * Kurze Zusammenfassung, was beim Import am Ende passiert ist.
 */
    public record ImportSummary(
            int importedProtocols,
            int upsertedSessions,
            int upsertedSpeeches,
            int upsertedDeputies,
            int upsertedVideos,
            int enrichedDeputyImages,
            int skippedInvalidSpeeches,
            int skippedInvalidDeputies,
            int skippedInvalidVideos
    ) {
    }

/**
 * Optionen für den Importlauf, damit der Aufruf nicht mit Parametern überladen wird.
 */
    public record ImportOptions(Integer legislativePeriodFilter, int maxProtocols, boolean forceReimportExisting) {

        // Damit hat der normale Importlauf einen festen Default, ohne überall dieselben Werte zu streuen.
        public static ImportOptions defaultOptions() {
            return new ImportOptions(null, 0, false);
        }
    }

/**
 * Hält einen möglichen Importtreffer aus der Bundestagsliste fest.
 */
    public record ImportCandidate(
            String protocolId,
            int legislativePeriod,
            int sessionNumber,
            String sourceUrl,
            boolean alreadyImported
    ) {
    }

    private record ValidationResult(
            ProtocolSession session,
            List<Speech> speeches,
            List<Deputy> deputies,
            List<SpeechVideo> videos,
            int invalidSpeechCount,
            int invalidDeputyCount,
            int invalidVideoCount
    ) {
    }
}
