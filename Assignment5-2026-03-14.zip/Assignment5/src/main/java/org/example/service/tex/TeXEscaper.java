package org.example.service.tex;

/**
 * @author
 */

/**
 * Sammelt die Logik für TeXEscaper.
 */
public final class TeXEscaper {
    private TeXEscaper() {
    }

    // Maskiert die üblichen TeX-Sonderzeichen, damit normaler Text nicht alles zerlegt.
    public static String escape(String value) {
        if (value == null) {
            return "";
        }
        // Reihenfolge ist hier wichtig, damit Backslashes nicht später nochmal kaputtgehen.
        return value
                .replace("\\", "\\textbackslash{}")
                .replace("{", "\\{")
                .replace("}", "\\}")
                .replace("$", "\\$")
                .replace("&", "\\&")
                .replace("%", "\\%")
                .replace("#", "\\#")
                .replace("_", "\\_")
                .replace("^", "\\textasciicircum{}")
                .replace("~", "\\textasciitilde{}");
    }
}
