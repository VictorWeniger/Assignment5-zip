package org.example.service;

import org.example.db.DatabaseHandler;
import org.example.model.Speech;
import org.example.model.SpeechVideo;
import org.example.service.nlp.NlpEngine;
import org.example.service.nlp.TextNormalizationUtil;
import org.example.service.nlp.UimaCasSerializer;
import org.example.service.nlp.VideoSentenceTimestampService;
import org.bson.Document;

import java.time.Instant;
import java.util.List;

/**
 * @author
 */

/**
 * Sammelt die Logik für NlpProcessingService.
 */
public class NlpProcessingService {
    private final DatabaseHandler<Speech> speechDatabase;
    private final NlpEngine primaryEngine;
    private final VideoSentenceTimestampService videoSentenceTimestampService;

    public NlpProcessingService(DatabaseHandler<Speech> speechDatabase) {
        this(speechDatabase, (NlpEngine) null);
    }

    public NlpProcessingService(DatabaseHandler<Speech> speechDatabase, NlpEngine primaryEngine) {
        this(speechDatabase, primaryEngine, null);
    }

    public NlpProcessingService(
            DatabaseHandler<Speech> speechDatabase,
            DatabaseHandler<SpeechVideo> speechVideoDatabase,
            NlpEngine primaryEngine
    ) {
        this(
                speechDatabase,
                primaryEngine,
                new VideoSentenceTimestampService(speechVideoDatabase)
        );
    }

    public NlpProcessingService(
            DatabaseHandler<Speech> speechDatabase,
            NlpEngine primaryEngine,
            VideoSentenceTimestampService videoSentenceTimestampService
    ) {
        this.speechDatabase = speechDatabase;
        this.primaryEngine = primaryEngine;
        this.videoSentenceTimestampService = videoSentenceTimestampService;
    }

    // Batch-Lauf über mehrere Reden. Wenn DUUI scheitert, knallt der Lauf bewusst hart weg.
    public NlpRunSummary run(int limit, boolean force) {
        Document filter = force
                ? new Document()
                : new Document("nlpProcessed", new Document("$ne", true));
        List<Speech> speeches = speechDatabase.findLimited("speeches", filter, Speech.class, limit);
        int processed = 0;
        int skipped = 0;

        for (Speech speech : speeches) {
            if (speech == null || speech.getId() == null || speech.getId().isBlank()) {
                skipped++;
                continue;
            }

            // Der Batch-Modus arbeitet jetzt nur noch mit DUUI:
            // wenn die Engine fehlschlägt, schlägt der Lauf fehl statt auf etwas anderes zurückzufallen.
            annotateWithPrimaryEngine(speech, force);
            speech.setNlpProcessed(true);
            speech.setNlpProcessedAt(Instant.now());
            speechDatabase.replaceById("speeches", speech.getId(), speech);
            processed++;
        }

        return new NlpRunSummary(processed, skipped);
    }

    // Dasselbe nochmal nur für eine Rede, z.B. direkt aus der Detailseite.
    public NlpRunSummary runSingleSpeech(String speechId, boolean force) {
        Speech speech = speechDatabase.findById("speeches", speechId, Speech.class).orElse(null);
        if (speech == null) {
            return new NlpRunSummary(0, 1);
        }
        if (speech.isNlpProcessed() && !force) {
            maybeEnrichTimestampsOnly(speech, false);
            return new NlpRunSummary(0, 1);
        }

        annotateWithPrimaryEngine(speech, force);
        speech.setNlpProcessed(true);
        speech.setNlpProcessedAt(Instant.now());
        speechDatabase.replaceById("speeches", speech.getId(), speech);
        return new NlpRunSummary(1, 0);
    }

    // Kleine Statistik für UI und schnellen Check.
    public Document stats() {
        long total = speechDatabase.count("speeches", new Document());
        long processed = speechDatabase.count("speeches", new Document("nlpProcessed", true));
        return new Document("totalSpeeches", total)
                .append("nlpProcessedSpeeches", processed)
                .append("nlpPendingSpeeches", Math.max(0, total - processed));
    }

    //----helper---
    private void annotateWithPrimaryEngine(Speech speech, boolean force) {
        // Stellt sicher, dass alle nachgelagerten NLP- und Zeitstempel-Schritte
        // mit bereinigtem Text arbeiten.
        normalizeSpeechTextIfNeeded(speech);
        if (primaryEngine == null) {
            throw new IllegalStateException("No DUUI NLP engine is configured");
        }
        primaryEngine.annotate(speech);

        ensureEngineMetadata(speech, primaryEngine.name());
        if (videoSentenceTimestampService != null) {
            // Fügt t0/t1 auf Satzebene hinzu, wenn Video- oder Transkript-Daten vorhanden sind.
            videoSentenceTimestampService.enrichSpeech(speech, force);
        }
        // Hält eine kompakte und stabile Serialisierung für Export und Debugging bereit.
        UimaCasSerializer.enrichSpeechWithUimaCas(speech);
    }

    private void maybeEnrichTimestampsOnly(Speech speech, boolean force) {
        if (videoSentenceTimestampService == null || speech == null) {
            return;
        }
        // Auch wenn NLP übersprungen wird, können Zeitmetadaten trotzdem noch verbessert werden.
        normalizeSpeechTextIfNeeded(speech);
        videoSentenceTimestampService.enrichSpeech(speech, force);
        UimaCasSerializer.enrichSpeechWithUimaCas(speech);
        if (speech.getId() != null && !speech.getId().isBlank()) {
            speechDatabase.replaceById("speeches", speech.getId(), speech);
        }
    }

    private void ensureEngineMetadata(Speech speech, String engineName) {
        if (speech.getNlp() == null) {
            speech.setNlp(new java.util.HashMap<>());
        }
        // Speichert den Namen der Engine, damit das UI DUUI-Ausgaben
        // von importierten XMI-Daten unterscheiden kann.
        speech.getNlp().put("processingEngine", engineName);
    }

    private void normalizeSpeechTextIfNeeded(Speech speech) {
        if (speech == null) {
            return;
        }
        String raw = speech.getText();
        String normalized = TextNormalizationUtil.sanitizeSpeechText(raw);
        if (raw == null || !raw.equals(normalized)) {
            speech.setText(normalized);
        }
    }

    public record NlpRunSummary(int processed, int skipped) {
    }
}
