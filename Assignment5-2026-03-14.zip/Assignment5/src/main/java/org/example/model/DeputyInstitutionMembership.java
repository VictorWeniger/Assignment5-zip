package org.example.model;

import java.time.LocalDate;

/**
 * @author
 */

/**
 * Mitgliedschaft eines Deputies in Fraktion oder anderem Gremium.
 */
public class DeputyInstitutionMembership {
    private String typeLabel;
    private String label;
    private LocalDate memberFrom;
    private LocalDate memberTo;
    private String functionLabel;
    private LocalDate functionFrom;
    private LocalDate functionTo;

    // Getter

public String getTypeLabel() {
        return typeLabel;
    }

    public String getLabel() {
        return label;
    }

    public LocalDate getMemberFrom() {
        return memberFrom;
    }

    public LocalDate getMemberTo() {
        return memberTo;
    }

    public String getFunctionLabel() {
        return functionLabel;
    }

    public LocalDate getFunctionFrom() {
        return functionFrom;
    }

    public LocalDate getFunctionTo() {
        return functionTo;
    }

    // Setter

    public void setTypeLabel(String typeLabel) {
        this.typeLabel = typeLabel;
    }


    public void setLabel(String label) {
        this.label = label;
    }

    public void setMemberFrom(LocalDate memberFrom) {
        this.memberFrom = memberFrom;
    }

    public void setMemberTo(LocalDate memberTo) {
        this.memberTo = memberTo;
    }

    public void setFunctionLabel(String functionLabel) {
        this.functionLabel = functionLabel;
    }

    public void setFunctionFrom(LocalDate functionFrom) {
        this.functionFrom = functionFrom;
    }

    public void setFunctionTo(LocalDate functionTo) {
        this.functionTo = functionTo;
    }

}
