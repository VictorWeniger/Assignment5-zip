package org.example.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @author
 */

/**
 * Mandatsdaten eines Deputies für genau eine Wahlperiode.
 */
public class DeputyLegislativePeriod {
    private int legislativePeriod;
    private LocalDate memberFrom;
    private LocalDate memberTo;
    private String constituencyNumber;
    private String constituencyName;
    private String constituencyState;
    private String listName;
    private String mandateType;
    private final List<DeputyInstitutionMembership> institutions = new ArrayList<>();

    // Getter

    public int getLegislativePeriod() {
        return legislativePeriod;
    }

    public LocalDate getMemberFrom() {
        return memberFrom;
    }

    public LocalDate getMemberTo() {
        return memberTo;
    }

    public String getConstituencyNumber() {
        return constituencyNumber;
    }

    public String getConstituencyName() {
        return constituencyName;
    }

    public String getConstituencyState() {
        return constituencyState;
    }

    public String getListName() {
        return listName;
    }

    public String getMandateType() {
        return mandateType;
    }

    public List<DeputyInstitutionMembership> getInstitutions() {
        return institutions;
    }

    // Setter

    public void setLegislativePeriod(int legislativePeriod) {
        this.legislativePeriod = legislativePeriod;
    }

    public void setMemberFrom(LocalDate memberFrom) {
        this.memberFrom = memberFrom;
    }

    public void setMemberTo(LocalDate memberTo) {
        this.memberTo = memberTo;
    }

    public void setConstituencyNumber(String constituencyNumber) {
        this.constituencyNumber = constituencyNumber;
    }

    public void setConstituencyName(String constituencyName) {
        this.constituencyName = constituencyName;
    }

    public void setConstituencyState(String constituencyState) {
        this.constituencyState = constituencyState;
    }

    public void setListName(String listName) {
        this.listName = listName;
    }

    public void setMandateType(String mandateType) {
        this.mandateType = mandateType;
    }

}
