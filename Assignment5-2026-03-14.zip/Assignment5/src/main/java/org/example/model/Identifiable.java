package org.example.model;

/**
 * @author
 */

/**
 * Hält die Daten für Identifiable.
 */
public interface Identifiable {
    String getId();
}
