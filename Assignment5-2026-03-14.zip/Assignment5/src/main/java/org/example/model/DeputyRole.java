package org.example.model;

/**
 * @author
 */

/**
 * Hält die Daten für DeputyRole.
 */
public enum DeputyRole {
    DEPUTY,
    PRESIDENT,
    MINISTER,
    SECRETARY,
    GUEST
}
