package org.example.model;

import java.time.Instant;

/**
 * @author
 */

/**
 * Hält die Daten für ExportTemplate.
 */
public class ExportTemplate implements Identifiable {
    private String id;
    private String name;
    private String content;
    private Instant updatedAt;

    // Getter
    @Override
    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getContent() {
        return content;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    // Setter
    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setUpdatedAt(Instant updatedAt) {
        this.updatedAt = updatedAt;
    }

}
