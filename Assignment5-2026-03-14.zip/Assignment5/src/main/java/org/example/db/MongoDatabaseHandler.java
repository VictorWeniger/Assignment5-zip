package org.example.db;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.ReplaceOptions;
import org.example.config.DatabaseConfig;
import org.example.util.DocumentMapper;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * @author
 */

/**
 * Kram für den Datenbankzugriff in MongoDatabaseHandler.
 */
public class MongoDatabaseHandler<T> implements DatabaseHandler<T>, AutoCloseable {
    private final MongoClient mongoClient;
    private final MongoDatabase database;

    public MongoDatabaseHandler(DatabaseConfig config) {
        this(MongoClients.create(config.connectionString()), config.databaseName());
    }

    public MongoDatabaseHandler(MongoClient mongoClient, String databaseName) {
        this.mongoClient = mongoClient;
        this.database = mongoClient.getDatabase(databaseName);
    }

    @Override
    // Schreibt ein Dokument neu in Collection.
    public void insert(String collection, T entity) {
        getCollection(collection).insertOne(DocumentMapper.toDocument(entity));
    }

    @Override
    // Upsert über die fachliche ID, damit bestehende Daten überschrieben werden können.
    public void replaceById(String collection, String id, T entity) {
        getCollection(collection).replaceOne(Filters.eq("id", id), DocumentMapper.toDocument(entity), new ReplaceOptions().upsert(true));
    }

    @Override
    // Holt genau einen Datensatz über  id-Feld.
    public Optional<T> findById(String collection, String id, Class<T> type) {
        Document document = getCollection(collection).find(Filters.eq("id", id)).first();
        if (document == null) {
            return Optional.empty();
        }
        return Optional.of(DocumentMapper.fromDocument(document, type));
    }

    @Override
    // Liest alle Treffer für einen Filter.
    public List<T> find(String collection, Document filter, Class<T> type) {
        List<T> values = new ArrayList<>();
        for (Document document : getCollection(collection).find(filter)) {
            values.add(DocumentMapper.fromDocument(document, type));
        }
        return values;
    }

    @Override
    // Dasselbe wie find, nur mit Limit.
    public List<T> findLimited(String collection, Document filter, Class<T> type, int limit) {
        if (limit <= 0) {
            return find(collection, filter, type);
        }
        List<T> values = new ArrayList<>();
        for (Document document : getCollection(collection).find(filter).limit(limit)) {
            values.add(DocumentMapper.fromDocument(document, type));
        }
        return values;
    }

    @Override
    // Gibt nur die Trefferzahl zurück.
    public long count(String collection, Document filter) {
        return getCollection(collection).countDocuments(filter);
    }

    @Override
    // Reicht Aggregation direkt an Mongo weiter.
    public List<Document> aggregate(String collection, List<Document> pipeline) {
        List<Document> values = new ArrayList<>();
        for (Document document : getCollection(collection).aggregate(pipeline)) {
            values.add(document);
        }
        return values;
    }

    @Override
    // Löscht über das fachliche id-Feld.
    public void deleteById(String collection, String id) {
        getCollection(collection).deleteOne(Filters.eq("id", id));
    }

    @Override
    // Macht den Mongo-Client beim Shutdown wieder zu.
    public void close() {
        mongoClient.close();
    }

    // Falls man an den rohen Client ranmuss, kommt man hier noch dran.
    public MongoClient mongoClient() {
        return mongoClient;
    }
    //----helper---
    // Zentrale Stelle für den Zugriff auf Collections, damit der Rest kurz bleibt.
    private MongoCollection<Document> getCollection(String collection) {
        return database.getCollection(collection);
    }
}
