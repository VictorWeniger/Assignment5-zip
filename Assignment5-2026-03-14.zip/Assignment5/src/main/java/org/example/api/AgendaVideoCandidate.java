package org.example.api;

/**
 * @author
 */

/**
 * Endpunkte für AgendaVideoCandidate.
 */
public record AgendaVideoCandidate(
        String protocolId,
        String sessionId,
        int legislativePeriod,
        int sessionNumber,
        int agendaItem,
        String agendaLabel,
        long speechCount,
        int speakerCount,
        String speechesUrl
) {
}
