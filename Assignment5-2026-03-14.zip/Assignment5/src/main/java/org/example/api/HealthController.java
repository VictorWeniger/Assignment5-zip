package org.example.api;

import io.javalin.Javalin;

/**
 * @author
 */

/**
 * Endpunkte für HealthController.
 */
public final class HealthController {
    private HealthController() {
    }

    // Minimaler Ping. Wenn das antwortet, lebt der Server noch.
    public static void register(Javalin app) {
        app.get("/health", ctx -> ctx.json("ok"));
    }
}
