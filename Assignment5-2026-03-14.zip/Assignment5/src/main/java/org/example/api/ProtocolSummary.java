package org.example.api;

import org.example.model.ProtocolDocument;

import java.time.Instant;

/**
 * @author
 */

/**
 * Endpunkte für ProtocolSummary.
 */
public record ProtocolSummary(
        String id,
        int legislativePeriod,
        int sessionNumber,
        String sourceUrl,
        Instant importedAt
) {
    // Nimmt ein volles Protokoll und bricht es auf die kleine Listenform runter.
    public static ProtocolSummary from(ProtocolDocument protocol) {
        return new ProtocolSummary(
                protocol.getId(),
                protocol.getLegislativePeriod(),
                protocol.getSessionNumber(),
                protocol.getSourceUrl(),
                protocol.getImportedAt()
        );
    }
}
