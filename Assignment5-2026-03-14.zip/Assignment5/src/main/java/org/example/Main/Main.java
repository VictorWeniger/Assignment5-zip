package org.example.Main;

import org.example.Application;

/**
 * @author
 */

/**
 * Kram rund um Main.
 */
public class Main {
    public static void main(String[] args) {
        Application.main(args);
    }
}
