# User Manual

## 1. Start the Application
1. Ensure MongoDB is running.
2. Set environment variables if needed:
   - `MPE_PORT` (default: `7070`)
   - `MPE_MONGO_URI` (default: `mongodb://localhost:27017`)
   - `MPE_MONGO_DB` (default: `multimodal_parliament_explorer`)
   - `MPE_IMPORT_INTERVAL_MINUTES` (default: `120`)
   - `MPE_DOWNLOAD_MEDIA` (default: `false`)
   - `MPE_MEDIA_DIR` (default: `data/media`)
   - `MPE_CREDENTIALS_FILE` (default: `.credentials/mpe.properties`)
   - `MPE_NLP_ENGINE` (`local`, `duui`, `auto`; default: `local`)
   - `MPE_DUUI_ENDPOINT` (optional)
   - `MPE_DUUI_TOKEN` (optional)
   - `MPE_DUUI_TIMEOUT_SECONDS` (default: `30`)
3. Run:
   - `mvn -Dmaven.repo.local=.m2repo compile`
   - `mvn -Dmaven.repo.local=.m2repo exec:java`

Credentials file support:
- Copy `.credentials/mpe.properties.example` to `.credentials/mpe.properties`.
- Put DUUI values there when you receive credentials.
- Environment variables always override file values.

## 2. Main Pages
- Home: `http://localhost:7070/`
- Protocols: `http://localhost:7070/protocols`
- Speeches: `http://localhost:7070/speeches`
- Speech detail: `http://localhost:7070/speech/{speechId}`
- Analytics: `http://localhost:7070/analytics`
- Export: `http://localhost:7070/export`
- Swagger: `http://localhost:7070/swagger`

## 3. Import Workflow
1. Open Home page.
2. Run import preview.
3. Run import.
4. Verify counts in `GET /api/stats`.

For targeted import:
- `POST /api/import/run/{protocolId}?force=false`

## 4. Speech Exploration
- Use filters on `/speeches`:
  - protocol ID
  - multiple protocol IDs (CSV via `protocolIds`)
  - speaker ID
  - faction
  - topic
  - time range (`from` / `to`)
  - `matchMode=and|or` for combining filters
- Use text search field for fulltext lookup.
- Open speech detail to inspect metadata, comments, and linked video.
- In speech detail you can run NLP for the current speech and toggle:
  - inline comments
  - named entities
  - coreferences
  - sentence-level sentiment overlay
- Comment metadata includes heuristic NLP attribution source/confidence when author fields are missing in raw XML.

## 5. Analytics
- Open `/analytics`.
- Filter by protocol, speech, faction, topic.
- Optional: use `protocolIds` (CSV) and `matchMode=and|or`.
- Load charts:
  - Topics radar
  - POS sunburst
  - Sentiment line
  - Named-entities bar

Note: NLP charts depend on available NLP annotations in speech documents.
You can import pre-annotated files via:
- `POST /api/nlp/import?path=/path/to/file.json&createMissing=false`

NLP engine behavior:
- `local`: always run in-app heuristic NLP.
- `duui`: prefer DUUI endpoint, fallback to local if unavailable/error.
- `auto`: use DUUI when endpoint exists, otherwise local.

## 6. Export
### TeX
- Open `/export`
- Set filters and title
- Optional: `protocolIds` (CSV), `matchMode=and|or`, `groupBy` (`protocol|speaker|faction|topic|none`), `from`/`to`
- Optional: `includeTikz=true` to embed small NLP statistic bars into generated TeX/PDF.
- Click **Generate TeX**

### PDF
- Click **Open PDF**
- If LaTeX (`pdflatex`) is unavailable, API returns 501 with details.

### Template Editing
- In `/export`, use Template Editor.
- Seed defaults with **Seed Defaults**.
- Load/edit/save templates by ID:
  - `document-header`
  - `speech-section`
  - `speech-entry`
  - `comment-entry`
  - `document-footer`

NLP serialization note:
- After NLP processing/import, each speech stores:
  - `nlp.uimaTypeSystem`
  - `nlp.uimaCas`
