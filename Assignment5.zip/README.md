# Multimodal Parliament Explorer

Backend core scaffold for Assignment 5.

## Requirements
- Java 21
- Maven 3.9+
- MongoDB

## Run
```bash
mvn -Dmaven.repo.local=.m2repo compile
mvn -Dmaven.repo.local=.m2repo test
```
At startup, the app creates MongoDB indexes for protocol/session/speech/deputy/video collections.

## Tests
```bash
mvn -Dmaven.repo.local=.m2repo test
```

## API Docs
- Swagger UI: `http://localhost:7070/swagger`
- OpenAPI spec: `http://localhost:7070/swagger/openapi.yaml`
- Quick route list: `http://localhost:7070/api/docs`

## Frontend Pages
- Home dashboard: `http://localhost:7070/`
- Protocol browser: `http://localhost:7070/protocols`
- Speech browser: `http://localhost:7070/speeches`
- Speech detail: `http://localhost:7070/speech/{speechId}`
- Analytics (d3 scaffolding): `http://localhost:7070/analytics`
- Export (TeX preview): `http://localhost:7070/export`

## Project Docs
- User manual: `docs/USER_MANUAL.md`
- Status snapshot: `docs/PROJECT_STATUS.md`
- Planning artifacts: `docs/planning/README.md`
- Deliverable checklist: `docs/DELIVERABLE_CHECKLIST.md`
- Frontend rubric check: `docs/FRONTEND_RUBRIC_CHECK.md`
- Smoke test runbook: `docs/SMOKE_TEST_RUNBOOK.md`
- Final report draft: `docs/FINAL_REPORT.md`
- Slide outline: `docs/SLIDES_OUTLINE.md`

## Useful Test Calls
- `GET /api/import/preview?period=20&limit=2`
- `POST /api/import/run?period=20&limit=2`
- `POST /api/import/run/20-42?force=true`
- `POST /api/nlp/run?limit=300`
- `POST /api/nlp/run/{speechId}?force=true`
- `POST /api/nlp/import?path=/path/to/annotations.json&createMissing=false`
- `GET /api/nlp/stats`
- `GET /api/stats`
- `GET /api/protocols?limit=20` (summary only)
- `GET /api/protocols?limit=5&includeRaw=true` (includes raw XML)
- `GET /api/speeches?faction=SPD&limit=20`
- `GET /api/speeches?protocolIds=20-42,20-43&topic=Climate&matchMode=or&limit=50`
- `GET /api/speeches?from=2026-01-01T00:00:00Z&to=2026-12-31T23:59:59Z&limit=20`
- `GET /api/speeches/search?q=klimaschutz&limit=20`
- `GET /api/speeches/{id}/detail`
- `GET /api/topics?limit=100`
- `GET /api/export/tex?protocolId=20-42&limit=50`
- `GET /api/export/pdf?protocolId=20-42&limit=50`
- `GET /api/export/tex?protocolIds=20-42,20-43&matchMode=or&groupBy=faction&from=2026-01-01T00:00:00Z&to=2026-12-31T23:59:59Z&limit=200`
- `GET /api/export/pdf?protocolId=20-42&groupBy=speaker&includeTikz=true&limit=100`
- `POST /api/templates/seed`
- `GET /api/templates`
- `PUT /api/templates/speech-section`
- `PUT /api/templates/speech-entry`

Validation notes:
- import `limit` max is `500`
- query `limit` max is `1000`

## Environment variables
- `MPE_PORT` (default: `7070`)
- `MPE_MONGO_URI` (default: `mongodb://localhost:27017`)
- `MPE_MONGO_DB` (default: `multimodal_parliament_explorer`)
- `MPE_IMPORT_INTERVAL_MINUTES` (default: `120`)
- `MPE_DOWNLOAD_MEDIA` (default: `false`)
- `MPE_MEDIA_DIR` (default: `data/media`)
- `MPE_CREDENTIALS_FILE` (default: `.credentials/mpe.properties`)
- `MPE_NLP_ENGINE` (`local`, `duui`, `auto`; default: `local`)
- `MPE_DUUI_ENDPOINT` (default: empty)
- `MPE_DUUI_TOKEN` (default: empty)
- `MPE_DUUI_TIMEOUT_SECONDS` (default: `30`)

## Credentials File
Copy `.credentials/mpe.properties.example` to `.credentials/mpe.properties` and fill values when provided:
```properties
mpe.nlp.engine=auto
mpe.duui.endpoint=
mpe.duui.token=
mpe.duui.timeoutSeconds=30
```
Environment variables override file values.
