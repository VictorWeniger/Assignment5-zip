package de.ppr.mpe.service.nlp;

import de.ppr.mpe.model.Comment;
import de.ppr.mpe.model.Deputy;
import de.ppr.mpe.model.ParliamentaryGroup;
import de.ppr.mpe.model.Speech;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class LocalHeuristicNlpEngineTest {
    @Test
    void infersCommentAttributionWhenCommentHasNoAuthor() {
        Speech speech = new Speech();
        speech.setId("s-1");
        speech.setText("Das ist eine kurze Rede.");

        Deputy deputy = new Deputy();
        deputy.setFirstName("Max");
        deputy.setLastName("Mustermann");
        ParliamentaryGroup group = new ParliamentaryGroup();
        group.setShortName("SPD");
        deputy.setParliamentaryGroup(group);
        speech.setSpeaker(deputy);

        Comment comment = new Comment();
        comment.setSpeechOffset(5);
        comment.setText("Das ist falsch, SPD!");
        speech.getComments().add(comment);

        new LocalHeuristicNlpEngine().annotate(speech);

        Object rows = speech.getNlp().get("commentAttributions");
        assertTrue(rows instanceof List<?>);
        assertFalse(((List<?>) rows).isEmpty());
        Object first = ((List<?>) rows).get(0);
        assertTrue(first instanceof Map<?, ?>);
    }
}
