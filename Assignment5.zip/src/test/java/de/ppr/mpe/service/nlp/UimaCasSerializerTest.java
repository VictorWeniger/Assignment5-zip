package de.ppr.mpe.service.nlp;

import de.ppr.mpe.model.Comment;
import de.ppr.mpe.model.Speech;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;

class UimaCasSerializerTest {
    @Test
    void enrichesSpeechWithTypeSystemAndCas() {
        Speech speech = new Speech();
        speech.setId("s-1");
        speech.setProtocolId("20-42");
        speech.setSessionId("20-42-1");
        speech.setText("Berlin ist gut.");
        speech.setTopics(List.of(Map.of("label", "Climate", "score", 2)));
        speech.setNamedEntities(List.of(Map.of("type", "LOC", "text", "Berlin", "begin", 0, "end", 6)));
        speech.setPosDistribution(Map.of("NOUN", 1));
        speech.setNlp(new HashMap<>());
        speech.getNlp().put("sentenceSentiments", List.of(Map.of("begin", 0, "end", 15, "score", 0.5)));
        speech.getNlp().put("coreferences", List.of(Map.of(
                "label", "berlin",
                "mentions", List.of(Map.of("begin", 0, "end", 6))
        )));

        Comment comment = new Comment();
        comment.setText("Zwischenruf");
        comment.setAuthorName("Max");
        comment.setSpeechOffset(7);
        speech.getComments().add(comment);

        UimaCasSerializer.enrichSpeechWithUimaCas(speech);

        assertTrue(speech.getNlp().containsKey("uimaTypeSystem"));
        assertTrue(speech.getNlp().containsKey("uimaCas"));
        assertTrue(speech.getNlp().containsKey("uimaSerializedAt"));
    }
}
