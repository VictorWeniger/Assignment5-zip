async function fetchJson(url, options = {}) {
  const res = await fetch(url, options);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function collectAnnotations(speech, toggles) {
  const text = speech?.text || "";
  const annotations = [];

  if (toggles.sentiment) {
    const rows = speech?.nlp?.sentenceSentiments || [];
    rows.forEach((row, idx) => {
      if (!Number.isInteger(row.begin) || !Number.isInteger(row.end) || row.end <= row.begin) return;
      let cls = "speech-sent-neutral";
      const score = Number(row.score ?? 0);
      if (score > 0.15) cls = "speech-sent-positive";
      else if (score < -0.15) cls = "speech-sent-negative";
      annotations.push({
        begin: row.begin,
        end: row.end,
        priority: 1,
        cls,
        title: `Sentiment ${score.toFixed(2)}`
      });
    });
  }

  if (toggles.entities) {
    const rows = speech?.nlp?.namedEntities || speech?.namedEntities || [];
    rows.forEach(row => {
      if (!Number.isInteger(row.begin) || !Number.isInteger(row.end) || row.end <= row.begin) return;
      annotations.push({
        begin: row.begin,
        end: row.end,
        priority: 2,
        cls: "speech-inline-entity",
        title: `Entity ${row.type || ""}`
      });
    });
  }

  if (toggles.sarcasm) {
    const rows = speech?.nlp?.sentenceSarcasm || speech?.sentenceSarcasm || [];
    const threshold = Number.isFinite(toggles.sarcasmThreshold) ? toggles.sarcasmThreshold : 0.45;
    rows.forEach(row => {
      if (!Number.isInteger(row.begin) || !Number.isInteger(row.end) || row.end <= row.begin) return;
      const score = Number(row.score ?? 0);
      if (score < threshold) return;
      annotations.push({
        begin: row.begin,
        end: row.end,
        priority: 3,
        cls: "speech-inline-sarcasm",
        title: `Sarcasm ${score.toFixed(2)}`
      });
    });
  }

  if (toggles.comments) {
    (speech?.comments || []).forEach(c => {
      const begin = Number(c.speechOffset);
      const t = c.text || "";
      if (!Number.isInteger(begin) || begin < 0 || !t) return;
      annotations.push({
        begin,
        end: begin + t.length,
        priority: 4,
        cls: "speech-inline-comment",
        title: "Comment"
      });
    });
  }

  return annotations
    .filter(a => a.begin >= 0 && a.end <= text.length && a.end > a.begin)
    .sort((a, b) => a.begin - b.begin || b.priority - a.priority);
}

function renderAnnotatedText(text, annotations) {
  if (!annotations.length) return escapeHtml(text);

  const starts = new Map();
  const ends = new Map();
  annotations.forEach((a, idx) => {
    if (!starts.has(a.begin)) starts.set(a.begin, []);
    if (!ends.has(a.end)) ends.set(a.end, []);
    starts.get(a.begin).push({ ...a, id: idx });
    ends.get(a.end).push({ ...a, id: idx });
  });

  const opened = [];
  let html = "";

  for (let i = 0; i <= text.length; i++) {
    const closeAt = ends.get(i) || [];
    if (closeAt.length) {
      closeAt.sort((x, y) => x.priority - y.priority).forEach(close => {
        const idx = opened.findIndex(o => o.id === close.id);
        if (idx >= 0) {
          // close nested tags from top until target and reopen others
          const toReopen = [];
          for (let j = opened.length - 1; j >= idx; j--) {
            html += "</span>";
            if (j !== idx) toReopen.push(opened[j]);
          }
          opened.splice(idx);
          toReopen.reverse().forEach(tag => {
            html += `<span class=\"${tag.cls}\" title=\"${escapeHtml(tag.title)}\">`;
            opened.push(tag);
          });
        }
      });
    }

    const openAt = starts.get(i) || [];
    if (openAt.length) {
      openAt.sort((x, y) => x.priority - y.priority).forEach(a => {
        const attrs = a.attrs
          ? Object.entries(a.attrs).map(([k, v]) => ` ${k}=\"${escapeHtml(v)}\"`).join("")
          : "";
        html += `<span class=\"${a.cls}\" title=\"${escapeHtml(a.title)}\"${attrs}>`;
        opened.push(a);
      });
    }

    if (i < text.length) {
      html += escapeHtml(text[i]);
    }
  }

  while (opened.length) {
    opened.pop();
    html += "</span>";
  }

  return html;
}

function renderCommentList(comments, speech = {}) {
  const list = document.getElementById("comment-list");
  list.innerHTML = "";

  if (!Array.isArray(comments) || comments.length === 0) {
    const p = document.createElement("p");
    p.className = "meta";
    p.textContent = "No comments available.";
    list.appendChild(p);
    return;
  }

  comments.forEach((c, idx) => {
    const div = document.createElement("div");
    div.className = "comment-item";
    const badge = c.authorFaction
      ? `<span class="comment-badge faction">FRA</span>`
      : `<span class="comment-badge speaker">SPK</span>`;
    const attributions = Array.isArray(speech?.nlp?.commentAttributions) ? speech.nlp.commentAttributions : [];
    const match = attributions.find(a => Number(a.speechOffset) === Number(c.speechOffset));
    const meta = `${idx + 1}. offset=${c.speechOffset ?? "n/a"} | ${c.authorName || "Unknown"} ${c.authorFaction ? `(${c.authorFaction})` : ""}${match?.source ? ` | source=${match.source}` : ""}${Number.isFinite(Number(match?.confidence)) ? ` | confidence=${Number(match.confidence).toFixed(2)}` : ""}`;
    div.innerHTML = `<div class=\"meta\">${badge} ${escapeHtml(meta)}</div><div>${escapeHtml(c.text || "")}</div>`;
    list.appendChild(div);
  });
}

function sentimentClass(score) {
  if (score > 0.15) return "positive";
  if (score < -0.15) return "negative";
  return "neutral";
}

function bindVideoSentimentLamp(videoEl, speech) {
  const lamp = document.getElementById("sentiment-lamp");
  if (!videoEl || !lamp) return;

  const rows = speech?.nlp?.sentenceSentiments || [];
  if (!rows.length) return;

  const durationFallback = rows.length;
  videoEl.addEventListener("timeupdate", () => {
    const duration = Number(videoEl.duration) > 0 ? videoEl.duration : durationFallback;
    const ratio = duration > 0 ? videoEl.currentTime / duration : 0;
    const idx = Math.min(rows.length - 1, Math.max(0, Math.floor(ratio * rows.length)));
    const score = Number(rows[idx]?.score ?? 0);
    lamp.className = `sentiment-lamp ${sentimentClass(score)}`;
  });
}

function renderSpeech(detail, toggles) {
  const speakerBox = document.getElementById("speaker-box");
  const videoBox = document.getElementById("video-box");
  const speechText = document.getElementById("speech-text");

  const speaker = detail.speaker || detail.speech?.speaker;
  if (speaker) {
    const name = `${speaker.title || ""} ${speaker.firstName || ""} ${speaker.lastName || ""}`.replace(/\s+/g, " ").trim();
    const faction = speaker.parliamentaryGroup?.shortName || "";
    speakerBox.innerHTML = `<strong>Speaker:</strong> ${escapeHtml(name || "Unknown")} ${faction ? `(${escapeHtml(faction)})` : ""}`;
  } else {
    speakerBox.textContent = "Speaker: Unknown";
  }

  const speech = detail.speech || {};
  const comments = Array.isArray(speech.comments) ? speech.comments : [];

  if (detail.video) {
    const src = escapeHtml(detail.video.sourceUrl);
    videoBox.innerHTML = `<strong>Video:</strong> <a href=\"${src}\" target=\"_blank\" rel=\"noopener\">${src}</a><div><video id=\"speech-video\" controls preload=\"none\" style=\"max-width:100%;margin-top:8px\"><source src=\"${src}\"></video></div>`;
    bindVideoSentimentLamp(document.getElementById("speech-video"), speech);
  } else {
    videoBox.textContent = "Video: none";
  }

  const annotations = collectAnnotations(speech, toggles);
  speechText.innerHTML = renderAnnotatedText(speech.text || "", annotations);
  renderCommentList(comments, speech);
}

function getToggles() {
  const thresholdEl = document.getElementById("sarcasm-threshold");
  return {
    comments: document.getElementById("toggle-comments").checked,
    entities: document.getElementById("toggle-entities").checked,
    sarcasm: document.getElementById("toggle-sarcasm").checked,
    sentiment: document.getElementById("toggle-sentiment").checked,
    sarcasmThreshold: Number(thresholdEl?.value ?? 0.45)
  };
}

let currentDetail = null;

async function loadSpeechDetail() {
  const speechId = window.SPEECH_ID;
  currentDetail = await fetchJson(`/api/speeches/${encodeURIComponent(speechId)}/detail`);
  renderSpeech(currentDetail, getToggles());
}

async function runNlpForSpeech() {
  const speechId = window.SPEECH_ID;
  await fetchJson(`/api/nlp/run/${encodeURIComponent(speechId)}?force=true`, { method: "POST" });
  await loadSpeechDetail();
}

["toggle-comments", "toggle-entities", "toggle-sarcasm", "toggle-sentiment"].forEach(id => {
  document.getElementById(id).addEventListener("change", () => {
    if (!currentDetail) return;
    renderSpeech(currentDetail, getToggles());
  });
});

const sarcasmThreshold = document.getElementById("sarcasm-threshold");
const sarcasmThresholdValue = document.getElementById("sarcasm-threshold-value");
if (sarcasmThreshold && sarcasmThresholdValue) {
  const updateSarcasmThresholdUi = () => {
    const value = Number(sarcasmThreshold.value || 0);
    sarcasmThresholdValue.textContent = value.toFixed(2);
    if (currentDetail) {
      renderSpeech(currentDetail, getToggles());
    }
  };
  sarcasmThreshold.addEventListener("input", updateSarcasmThresholdUi);
  updateSarcasmThresholdUi();
}

document.getElementById("run-nlp-speech").addEventListener("click", () => {
  runNlpForSpeech().catch(err => {
    document.getElementById("speech-text").textContent = `Failed to run NLP: ${err.message}`;
  });
});

loadSpeechDetail().catch(err => {
  document.getElementById("speech-text").textContent = `Failed to load speech detail: ${err.message}`;
});
