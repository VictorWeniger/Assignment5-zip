async function fetchJson(url, options = {}) {
  const res = await fetch(url, options);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

function setOutput(value) {
  document.getElementById("quick-output").textContent = JSON.stringify(value, null, 2);
}

async function loadStats() {
  try {
    const [stats, nlpStats] = await Promise.all([
      fetchJson("/api/stats"),
      fetchJson("/api/nlp/stats")
    ]);

    const merged = { ...stats, ...nlpStats };
    const container = document.getElementById("stats-grid");
    container.innerHTML = "";
    Object.entries(merged).forEach(([key, value]) => {
      const el = document.createElement("div");
      el.className = "stat";
      el.innerHTML = `<div class="k">${key}</div><div class="v">${value}</div>`;
      container.appendChild(el);
    });
  } catch (err) {
    setOutput({ error: err.message });
  }
}

document.getElementById("preview-import").addEventListener("click", async () => {
  try {
    const data = await fetchJson("/api/import/preview?period=20&limit=3");
    setOutput(data);
  } catch (err) {
    setOutput({ error: err.message });
  }
});

document.getElementById("run-import").addEventListener("click", async () => {
  try {
    const data = await fetchJson("/api/import/run?period=20&limit=1", { method: "POST" });
    setOutput(data);
    await loadStats();
  } catch (err) {
    setOutput({ error: err.message });
  }
});

document.getElementById("run-nlp").addEventListener("click", async () => {
  try {
    const data = await fetchJson("/api/nlp/run?limit=300", { method: "POST" });
    setOutput(data);
    await loadStats();
  } catch (err) {
    setOutput({ error: err.message });
  }
});

document.getElementById("import-nlp-file").addEventListener("click", async () => {
  try {
    const path = document.getElementById("nlp-file-path").value.trim();
    if (!path) {
      setOutput({ error: "Please provide an NLP file path." });
      return;
    }
    const data = await fetchJson(`/api/nlp/import?path=${encodeURIComponent(path)}&createMissing=false`, { method: "POST" });
    setOutput(data);
    await loadStats();
  } catch (err) {
    setOutput({ error: err.message });
  }
});

loadStats();
