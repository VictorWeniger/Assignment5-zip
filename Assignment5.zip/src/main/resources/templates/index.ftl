<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${title}</title>
  <link rel="stylesheet" href="/css/app.css"/>
</head>
<body>
<header class="topbar">
  <h1>${title}</h1>
  <nav>
    <a href="/">Home</a>
    <a href="/protocols">Protocols</a>
    <a href="/speeches">Speeches</a>
    <a href="/analytics">Analytics</a>
    <a href="/export">Export</a>
    <a href="/swagger">Swagger</a>
  </nav>
</header>
<main class="container">
  <section class="card">
    <h2>System Stats</h2>
    <div id="stats-grid" class="stats-grid"></div>
  </section>
  <section class="card">
    <h2>Quick Actions</h2>
    <div class="actions">
      <button id="preview-import">Preview Import (period 20, limit 3)</button>
      <button id="run-import">Run Import (period 20, limit 1)</button>
      <button id="run-nlp">Run NLP (limit 300)</button>
    </div>
    <div class="row wrap">
      <label for="nlp-file-path">NLP file path</label>
      <input id="nlp-file-path" placeholder="/path/to/annotations.json or .jsonl"/>
      <button id="import-nlp-file">Import NLP File</button>
    </div>
    <pre id="quick-output" class="output"></pre>
  </section>
</main>
<script src="/js/index.js"></script>
</body>
</html>
