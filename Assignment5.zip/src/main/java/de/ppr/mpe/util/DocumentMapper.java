package de.ppr.mpe.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.bson.Document;

import java.util.Map;

/**
 * Converts between typed Java objects and MongoDB {@link Document} instances.
 */
public final class DocumentMapper {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule());

    private DocumentMapper() {
    }

    /**
     * Serializes one value object into a Mongo document.
     */
    public static <T> Document toDocument(T value) {
        Map<String, Object> map = OBJECT_MAPPER.convertValue(value, new TypeReference<>() {
        });
        return new Document(map);
    }

    /**
     * Deserializes a Mongo document into a typed value object.
     */
    public static <T> T fromDocument(Document document, Class<T> type) {
        return OBJECT_MAPPER.convertValue(document, type);
    }
}
