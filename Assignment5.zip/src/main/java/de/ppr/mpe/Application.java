package de.ppr.mpe;

import de.ppr.mpe.api.ApiDocsController;
import de.ppr.mpe.api.ExportController;
import de.ppr.mpe.api.FrontendController;
import de.ppr.mpe.api.HealthController;
import de.ppr.mpe.api.ImportController;
import de.ppr.mpe.api.NlpController;
import de.ppr.mpe.api.ProtocolController;
import de.ppr.mpe.api.SwaggerController;
import de.ppr.mpe.api.TemplateController;
import de.ppr.mpe.config.AppConfig;
import de.ppr.mpe.db.MongoDatabaseHandler;
import de.ppr.mpe.model.Deputy;
import de.ppr.mpe.model.ExportTemplate;
import de.ppr.mpe.model.ProtocolDocument;
import de.ppr.mpe.model.ProtocolSession;
import de.ppr.mpe.model.Speech;
import de.ppr.mpe.model.SpeechVideo;
import de.ppr.mpe.service.BundestagProtocolDownloader;
import de.ppr.mpe.service.DatabaseIndexInitializer;
import de.ppr.mpe.service.DeputyImageEnrichmentService;
import de.ppr.mpe.service.ImportScheduler;
import de.ppr.mpe.service.MediaAssetDownloadService;
import de.ppr.mpe.service.NlpAnnotationImportService;
import de.ppr.mpe.service.NlpProcessingService;
import de.ppr.mpe.service.ProtocolImportService;
import de.ppr.mpe.service.XmlProtocolParser;
import de.ppr.mpe.service.nlp.NlpEngineSelector;
import io.javalin.Javalin;
import io.javalin.http.ContentType;
import io.javalin.rendering.template.JavalinFreemarker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Application bootstrap for wiring configuration, services, routes, and lifecycle hooks.
 */
public class Application {
    private static final Logger LOGGER = LoggerFactory.getLogger(Application.class);

    /**
     * Starts the backend application.
     */
    public static void main(String[] args) {
        AppConfig config = AppConfig.fromEnvironment();

        MongoDatabaseHandler<ProtocolDocument> protocolDatabase = new MongoDatabaseHandler<>(config.databaseConfig());
        MongoDatabaseHandler<ProtocolSession> sessionDatabase = new MongoDatabaseHandler<>(config.databaseConfig());
        MongoDatabaseHandler<Speech> speechDatabase = new MongoDatabaseHandler<>(config.databaseConfig());
        MongoDatabaseHandler<Deputy> deputyDatabase = new MongoDatabaseHandler<>(config.databaseConfig());
        MongoDatabaseHandler<SpeechVideo> speechVideoDatabase = new MongoDatabaseHandler<>(config.databaseConfig());
        MongoDatabaseHandler<ExportTemplate> templateDatabase = new MongoDatabaseHandler<>(config.databaseConfig());
        new DatabaseIndexInitializer(protocolDatabase.mongoClient(), config.databaseConfig().databaseName()).ensureIndexes();

        ProtocolImportService importService = new ProtocolImportService(
                new BundestagProtocolDownloader(),
                protocolDatabase,
                sessionDatabase,
                speechDatabase,
                deputyDatabase,
                speechVideoDatabase,
                new DeputyImageEnrichmentService(),
                new MediaAssetDownloadService(config.downloadMediaAssets(), config.mediaDirectory()),
                new XmlProtocolParser()
        );
        NlpProcessingService nlpService = new NlpProcessingService(
                speechDatabase,
                NlpEngineSelector.select(config.nlpConfig())
        );
        NlpAnnotationImportService nlpImportService = new NlpAnnotationImportService(speechDatabase);

        ImportScheduler scheduler = new ImportScheduler();
        scheduler.schedule(importService, config.importInterval());

        Javalin app = Javalin.create(javalinConfig -> {
            javalinConfig.showJavalinBanner = false;
            javalinConfig.bundledPlugins.enableCors(cors -> cors.addRule(rule -> rule.anyHost()));
            javalinConfig.staticFiles.add("/public");
            javalinConfig.fileRenderer(new JavalinFreemarker());
        }).start(config.port());
        app.before(ctx -> {
            if (ctx.path().startsWith("/api")) {
                ctx.contentType(ContentType.JSON);
            }
        });
        app.exception(Exception.class, (e, ctx) -> {
            LOGGER.error("Unhandled server error", e);
            ctx.status(500).json(java.util.Map.of(
                    "error", "internal_server_error",
                    "message", String.valueOf(e.getMessage())
            ));
        });

        HealthController.register(app);
        ApiDocsController.register(app);
        SwaggerController.register(app);
        ImportController.register(app, importService);
        ProtocolController.register(app, protocolDatabase, sessionDatabase, speechDatabase, deputyDatabase, speechVideoDatabase);
        ExportController.register(app, speechDatabase, templateDatabase);
        TemplateController.register(app, templateDatabase);
        NlpController.register(app, nlpService, nlpImportService);
        FrontendController.register(app);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            scheduler.close();
            protocolDatabase.close();
            sessionDatabase.close();
            speechDatabase.close();
            deputyDatabase.close();
            speechVideoDatabase.close();
            templateDatabase.close();
            app.stop();
        }));
    }
}
