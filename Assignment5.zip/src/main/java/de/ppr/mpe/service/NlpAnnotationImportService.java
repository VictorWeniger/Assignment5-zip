package de.ppr.mpe.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.ppr.mpe.db.DatabaseHandler;
import de.ppr.mpe.model.Speech;
import de.ppr.mpe.service.nlp.UimaCasSerializer;
import org.bson.Document;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Imports externally generated NLP annotations from JSON/JSONL into speech documents.
 */
public class NlpAnnotationImportService {
    private final DatabaseHandler<Speech> speechDatabase;
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Creates a new import service bound to the speech collection.
     */
    public NlpAnnotationImportService(DatabaseHandler<Speech> speechDatabase) {
        this.speechDatabase = speechDatabase;
    }

    /**
     * Imports annotation rows from a file and updates or creates speeches.
     *
     * @param filePath input path to JSON array or JSONL file
     * @param createMissing whether missing speech ids should be created
     * @return summary with processed/update/create/skip counts
     */
    public ImportResult importFromFile(String filePath, boolean createMissing) {
        Path path = Path.of(filePath);
        if (!Files.exists(path)) {
            throw new IllegalArgumentException("File does not exist: " + filePath);
        }

        int processed = 0;
        int updated = 0;
        int created = 0;
        int skipped = 0;

        try {
            String content = Files.readString(path);
            List<JsonNode> rows = parseRows(content);
            for (JsonNode row : rows) {
                processed++;
                String speechId = text(row, "speechId", "id", "speech_id");
                if (speechId == null || speechId.isBlank()) {
                    skipped++;
                    continue;
                }

                Optional<Speech> existing = speechDatabase.findById("speeches", speechId, Speech.class);
                Speech speech;
                if (existing.isPresent()) {
                    speech = existing.get();
                    updated++;
                } else if (createMissing) {
                    speech = new Speech();
                    speech.setId(speechId);
                    speech.setText(text(row, "text", "speechText", "content"));
                    created++;
                } else {
                    skipped++;
                    continue;
                }

                JsonNode nlp = first(row, "nlp", "annotations");
                if (nlp != null && !nlp.isNull()) {
                    speech.setNlp(objectMapper.convertValue(nlp, java.util.Map.class));
                }

                JsonNode topics = first(row, "topics");
                if (topics != null && topics.isArray()) {
                    speech.setTopics(objectMapper.convertValue(topics, List.class));
                }

                JsonNode pos = first(row, "posDistribution", "pos_distribution");
                if (pos != null && pos.isObject()) {
                    speech.setPosDistribution(objectMapper.convertValue(pos, java.util.Map.class));
                }

                JsonNode entities = first(row, "namedEntities", "named_entities", "entities");
                if (entities != null && entities.isArray()) {
                    speech.setNamedEntities(objectMapper.convertValue(entities, List.class));
                }

                JsonNode sentenceSentiments = first(row, "sentenceSentiments", "sentence_sentiments");
                if (sentenceSentiments != null && sentenceSentiments.isArray()) {
                    speech.setSentenceSentiments(extractSentimentValues(sentenceSentiments));
                    if (speech.getNlp() == null) {
                        speech.setNlp(new java.util.HashMap<>());
                    }
                    speech.getNlp().put("sentenceSentiments", objectMapper.convertValue(sentenceSentiments, List.class));
                }

                JsonNode sentiments = first(row, "sentiments");
                if (sentiments != null && sentiments.isArray()) {
                    speech.setSentiments(extractSentimentValues(sentiments));
                }

                speech.setNlpProcessed(true);
                speech.setNlpProcessedAt(Instant.now());
                UimaCasSerializer.enrichSpeechWithUimaCas(speech);
                speechDatabase.replaceById("speeches", speech.getId(), speech);
            }
        } catch (IOException e) {
            throw new IllegalArgumentException("Could not read file: " + filePath, e);
        }

        return new ImportResult(processed, updated, created, skipped);
    }

    /**
     * Returns import progress counters based on persisted NLP flags.
     */
    public Document stats() {
        long total = speechDatabase.count("speeches", new Document());
        long processed = speechDatabase.count("speeches", new Document("nlpProcessed", true));
        return new Document("totalSpeeches", total)
                .append("nlpProcessedSpeeches", processed)
                .append("nlpPendingSpeeches", Math.max(0, total - processed));
    }

    private List<Double> extractSentimentValues(JsonNode arr) {
        List<Double> values = new ArrayList<>();
        for (JsonNode node : arr) {
            if (node.isNumber()) {
                values.add(node.asDouble());
                continue;
            }
            JsonNode score = first(node, "score", "value");
            if (score != null && score.isNumber()) {
                values.add(score.asDouble());
            }
        }
        return values;
    }

    private List<JsonNode> parseRows(String content) throws IOException {
        List<JsonNode> rows = new ArrayList<>();
        String trimmed = content.trim();
        if (trimmed.startsWith("[")) {
            JsonNode root = objectMapper.readTree(trimmed);
            root.forEach(rows::add);
            return rows;
        }

        for (String line : content.split("\\R")) {
            String l = line.trim();
            if (l.isBlank()) {
                continue;
            }
            rows.add(objectMapper.readTree(l));
        }
        return rows;
    }

    private JsonNode first(JsonNode node, String... names) {
        if (node == null) {
            return null;
        }
        for (String name : names) {
            JsonNode value = node.get(name);
            if (value != null && !value.isNull()) {
                return value;
            }
        }
        return null;
    }

    private String text(JsonNode node, String... names) {
        JsonNode value = first(node, names);
        if (value == null || value.isNull()) {
            return "";
        }
        return value.asText("");
    }

    /**
     * Result payload for a single import run.
     *
     * @param processed processed rows
     * @param updated existing speeches updated
     * @param created new speeches created
     * @param skipped rows skipped due to validation/matching rules
     */
    public record ImportResult(int processed, int updated, int created, int skipped) {
    }
}
