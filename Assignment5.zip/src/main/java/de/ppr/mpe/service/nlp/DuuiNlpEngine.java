package de.ppr.mpe.service.nlp;

import de.ppr.mpe.config.NlpConfig;
import de.ppr.mpe.model.Speech;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * NLP engine implementation backed by a DUUI HTTP endpoint.
 */
public class DuuiNlpEngine implements NlpEngine {
    private final HttpClient httpClient;
    private final NlpConfig config;

    /**
     * Creates a DUUI engine with the provided configuration.
     */
    public DuuiNlpEngine(NlpConfig config) {
        this.httpClient = HttpClient.newHttpClient();
        this.config = config;
    }

    /**
     * Engine identifier used in logs and metadata.
     */
    @Override
    public String name() {
        return "duui";
    }

    /**
     * DUUI is available when an endpoint URL is configured.
     */
    @Override
    public boolean isAvailable() {
        return config != null && config.hasDuuiEndpoint();
    }

    /**
     * Sends speech text to DUUI and maps the response onto speech NLP fields.
     */
    @Override
    public void annotate(Speech speech) {
        if (!isAvailable()) {
            throw new IllegalStateException("DUUI endpoint is not configured");
        }

        JSONObject payload = new JSONObject();
        payload.put("speechId", speech.getId() == null ? "" : speech.getId());
        payload.put("text", speech.getText() == null ? "" : speech.getText());

        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(URI.create(config.duuiEndpoint()))
                .timeout(Duration.ofSeconds(Math.max(1, config.duuiTimeoutSeconds())))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(payload.toString()));

        if (config.hasDuuiToken()) {
            builder.header("Authorization", "Bearer " + config.duuiAuthToken());
        }

        HttpRequest request = builder.build();
        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new IllegalStateException("DUUI request failed: HTTP " + response.statusCode());
            }
            JSONObject parsed = new JSONObject(response.body());
            Map<String, Object> nlp = parsed.toMap();
            speech.setNlp(nlp);
            mapTopLevelFields(speech, parsed);
        } catch (IOException | InterruptedException e) {
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            throw new IllegalStateException("DUUI request failed: " + e.getMessage(), e);
        }
    }

    private void mapTopLevelFields(Speech speech, JSONObject parsed) {
        speech.setTopics(valueAsObjectList(parsed.opt("topics")));
        speech.setNamedEntities(valueAsObjectList(parsed.opt("namedEntities")));
        speech.setPosDistribution(valueAsIntMap(parsed.optJSONObject("posDistribution")));
        speech.setSentenceSentiments(valueAsDoubleList(parsed.opt("sentenceSentiments")));
        speech.setSentiments(valueAsDoubleList(parsed.opt("sentiments")));
    }

    private java.util.List<Object> valueAsObjectList(Object value) {
        if (value instanceof JSONArray array) {
            return array.toList();
        }
        if (value instanceof java.util.List<?> list) {
            return new java.util.ArrayList<>(list);
        }
        return new java.util.ArrayList<>();
    }

    private java.util.List<Double> valueAsDoubleList(Object value) {
        java.util.List<Double> out = new java.util.ArrayList<>();
        if (value instanceof JSONArray array) {
            for (int i = 0; i < array.length(); i++) {
                Object item = array.get(i);
                if (item instanceof Number n) {
                    out.add(n.doubleValue());
                }
            }
        } else if (value instanceof java.util.List<?> list) {
            for (Object item : list) {
                if (item instanceof Number n) {
                    out.add(n.doubleValue());
                }
            }
        }
        return out;
    }

    private Map<String, Integer> valueAsIntMap(JSONObject object) {
        Map<String, Integer> out = new HashMap<>();
        if (object == null) {
            return out;
        }
        for (String key : object.keySet()) {
            Object value = object.get(key);
            if (value instanceof Number n) {
                out.put(key, n.intValue());
            }
        }
        return out;
    }
}
