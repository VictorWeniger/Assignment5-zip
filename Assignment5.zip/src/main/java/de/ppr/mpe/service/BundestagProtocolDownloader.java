package de.ppr.mpe.service;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Fetches Bundestag protocol XML links and downloads XML payloads.
 */
public class BundestagProtocolDownloader {
    private static final String OPEN_DATA_URL = "https://www.bundestag.de/services/opendata";

    /**
     * Loads all XML links from the Bundestag open data page.
     */
    public List<String> fetchProtocolXmlLinks() throws IOException {
        Document document = Jsoup.connect(OPEN_DATA_URL).get();
        List<String> links = new ArrayList<>();

        for (Element anchor : document.select("a[href$=.xml]")) {
            String url = anchor.absUrl("href");
            if (!url.isBlank()) {
                links.add(url);
            }
        }
        return links;
    }

    /**
     * Downloads one XML document by URL.
     */
    public String downloadXml(String url) throws IOException {
        return Jsoup.connect(url)
                .ignoreContentType(true)
                .execute()
                .body();
    }
}
