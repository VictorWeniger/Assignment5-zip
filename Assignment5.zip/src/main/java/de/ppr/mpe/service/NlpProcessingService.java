package de.ppr.mpe.service;

import de.ppr.mpe.db.DatabaseHandler;
import de.ppr.mpe.model.Speech;
import de.ppr.mpe.service.nlp.LocalHeuristicNlpEngine;
import de.ppr.mpe.service.nlp.NlpEngine;
import de.ppr.mpe.service.nlp.UimaCasSerializer;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.List;

/**
 * Coordinates NLP annotation runs for speeches and persists processing metadata.
 */
public class NlpProcessingService {
    private static final Logger LOGGER = LoggerFactory.getLogger(NlpProcessingService.class);

    private final DatabaseHandler<Speech> speechDatabase;
    private final NlpEngine primaryEngine;
    private final NlpEngine fallbackEngine;

    /**
     * Creates a service that uses the local heuristic engine as primary and fallback engine.
     */
    public NlpProcessingService(DatabaseHandler<Speech> speechDatabase) {
        this(speechDatabase, new LocalHeuristicNlpEngine(), new LocalHeuristicNlpEngine());
    }

    /**
     * Creates a service with a custom primary engine and local fallback engine.
     */
    public NlpProcessingService(DatabaseHandler<Speech> speechDatabase, NlpEngine primaryEngine) {
        this(speechDatabase, primaryEngine, new LocalHeuristicNlpEngine());
    }

    /**
     * Creates a service with explicit primary and fallback engines.
     */
    public NlpProcessingService(DatabaseHandler<Speech> speechDatabase, NlpEngine primaryEngine, NlpEngine fallbackEngine) {
        this.speechDatabase = speechDatabase;
        this.primaryEngine = primaryEngine;
        this.fallbackEngine = fallbackEngine;
    }

    /**
     * Runs NLP processing on speeches up to {@code limit}.
     *
     * @param limit maximum number of speeches to process
     * @param force reprocess speeches even if they were already processed
     * @return summary containing processed and skipped counts
     */
    public NlpRunSummary run(int limit, boolean force) {
        List<Speech> speeches = speechDatabase.find("speeches", new Document(), Speech.class);
        int processed = 0;
        int skipped = 0;

        for (Speech speech : speeches) {
            if (processed >= limit) {
                break;
            }
            if (speech == null || speech.getId() == null || speech.getId().isBlank()) {
                skipped++;
                continue;
            }
            if (speech.isNlpProcessed() && !force) {
                skipped++;
                continue;
            }

            annotateWithFallback(speech);
            speech.setNlpProcessed(true);
            speech.setNlpProcessedAt(Instant.now());
            speechDatabase.replaceById("speeches", speech.getId(), speech);
            processed++;
        }

        return new NlpRunSummary(processed, skipped);
    }

    /**
     * Runs NLP processing for one speech by id.
     *
     * @param speechId speech identifier
     * @param force reprocess speech even if it was already processed
     * @return summary containing processed and skipped counts
     */
    public NlpRunSummary runSingleSpeech(String speechId, boolean force) {
        Speech speech = speechDatabase.findById("speeches", speechId, Speech.class).orElse(null);
        if (speech == null) {
            return new NlpRunSummary(0, 1);
        }
        if (speech.isNlpProcessed() && !force) {
            return new NlpRunSummary(0, 1);
        }

        annotateWithFallback(speech);
        speech.setNlpProcessed(true);
        speech.setNlpProcessedAt(Instant.now());
        speechDatabase.replaceById("speeches", speech.getId(), speech);
        return new NlpRunSummary(1, 0);
    }

    /**
     * Returns aggregate counters for NLP processing progress.
     */
    public Document stats() {
        long total = speechDatabase.count("speeches", new Document());
        long processed = speechDatabase.count("speeches", new Document("nlpProcessed", true));
        return new Document("totalSpeeches", total)
                .append("nlpProcessedSpeeches", processed)
                .append("nlpPendingSpeeches", Math.max(0, total - processed));
    }

    private void annotateWithFallback(Speech speech) {
        try {
            primaryEngine.annotate(speech);
            ensureEngineMetadata(speech, primaryEngine.name());
        } catch (RuntimeException ex) {
            if (fallbackEngine == null || primaryEngine.name().equals(fallbackEngine.name())) {
                throw ex;
            }
            LOGGER.warn("NLP engine '{}' failed for speech {}. Falling back to '{}'. Cause: {}",
                    primaryEngine.name(), speech.getId(), fallbackEngine.name(), ex.getMessage());
            fallbackEngine.annotate(speech);
            ensureEngineMetadata(speech, fallbackEngine.name());
        }
    }

    private void ensureEngineMetadata(Speech speech, String engineName) {
        if (speech.getNlp() == null) {
            speech.setNlp(new java.util.HashMap<>());
        }
        speech.getNlp().put("processingEngine", engineName);
        UimaCasSerializer.enrichSpeechWithUimaCas(speech);
    }

    /**
     * Value object returned by NLP run operations.
     *
     * @param processed number of speeches processed
     * @param skipped number of speeches skipped
     */
    public record NlpRunSummary(int processed, int skipped) {
    }
}
