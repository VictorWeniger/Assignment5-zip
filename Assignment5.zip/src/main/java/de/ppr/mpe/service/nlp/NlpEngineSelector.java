package de.ppr.mpe.service.nlp;

import de.ppr.mpe.config.NlpConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Chooses the active NLP engine based on runtime configuration and availability.
 */
public final class NlpEngineSelector {
    private static final Logger LOGGER = LoggerFactory.getLogger(NlpEngineSelector.class);

    private NlpEngineSelector() {
    }

    /**
     * Selects the NLP engine implementation for the current configuration.
     */
    public static NlpEngine select(NlpConfig config) {
        NlpEngine local = new LocalHeuristicNlpEngine();
        NlpEngine duui = new DuuiNlpEngine(config);

        if (config == null) {
            LOGGER.info("NLP engine: LOCAL (default)");
            return local;
        }

        return switch (config.engineMode()) {
            case LOCAL -> {
                LOGGER.info("NLP engine: LOCAL (configured)");
                yield local;
            }
            case DUUI -> {
                if (!duui.isAvailable()) {
                    LOGGER.warn("NLP engine DUUI requested but endpoint is missing. Falling back to LOCAL.");
                    yield local;
                }
                LOGGER.info("NLP engine: DUUI");
                yield duui;
            }
            case AUTO -> {
                if (duui.isAvailable()) {
                    LOGGER.info("NLP engine: DUUI (AUTO mode)");
                    yield duui;
                }
                LOGGER.info("NLP engine: LOCAL (AUTO mode, no DUUI endpoint)");
                yield local;
            }
        };
    }
}
