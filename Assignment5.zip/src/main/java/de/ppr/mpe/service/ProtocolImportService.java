package de.ppr.mpe.service;

import de.ppr.mpe.db.DatabaseHandler;
import de.ppr.mpe.model.Deputy;
import de.ppr.mpe.model.ImageMetadata;
import de.ppr.mpe.model.ProtocolDocument;
import de.ppr.mpe.model.ProtocolSession;
import de.ppr.mpe.model.Speech;
import de.ppr.mpe.model.SpeechVideo;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.Instant;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Orchestrates end-to-end protocol import from source discovery to validated database upserts.
 */
public class ProtocolImportService {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProtocolImportService.class);

    private final BundestagProtocolDownloader downloader;
    private final DatabaseHandler<ProtocolDocument> protocolDatabase;
    private final DatabaseHandler<ProtocolSession> sessionDatabase;
    private final DatabaseHandler<Speech> speechDatabase;
    private final DatabaseHandler<Deputy> deputyDatabase;
    private final DatabaseHandler<SpeechVideo> speechVideoDatabase;
    private final DeputyImageEnrichmentService deputyImageEnrichmentService;
    private final MediaAssetDownloadService mediaAssetDownloadService;
    private final XmlProtocolParser parser;

    /**
     * Creates a protocol import service with downloader, parser, enrichment, and persistence dependencies.
     */
    public ProtocolImportService(
            BundestagProtocolDownloader downloader,
            DatabaseHandler<ProtocolDocument> protocolDatabase,
            DatabaseHandler<ProtocolSession> sessionDatabase,
            DatabaseHandler<Speech> speechDatabase,
            DatabaseHandler<Deputy> deputyDatabase,
            DatabaseHandler<SpeechVideo> speechVideoDatabase,
            DeputyImageEnrichmentService deputyImageEnrichmentService,
            MediaAssetDownloadService mediaAssetDownloadService,
            XmlProtocolParser parser
    ) {
        this.downloader = downloader;
        this.protocolDatabase = protocolDatabase;
        this.sessionDatabase = sessionDatabase;
        this.speechDatabase = speechDatabase;
        this.deputyDatabase = deputyDatabase;
        this.speechVideoDatabase = speechVideoDatabase;
        this.deputyImageEnrichmentService = deputyImageEnrichmentService;
        this.mediaAssetDownloadService = mediaAssetDownloadService;
        this.parser = parser;
    }

    /**
     * Imports all missing protocols using default options.
     */
    public ImportSummary importMissingProtocols() {
        return importProtocols(ImportOptions.defaultOptions());
    }

    /**
     * Builds a preview of import candidates without writing data.
     */
    public List<ImportCandidate> previewImportCandidates(ImportOptions options) {
        try {
            List<String> xmlLinks = filterLinks(downloader.fetchProtocolXmlLinks(), options);
            return xmlLinks.stream().map(link -> {
                try {
                    ProtocolIdParser.ParsedProtocolId parsed = ProtocolIdParser.parse(link);
                    boolean exists = protocolDatabase.count("protocols", new Document("id", parsed.protocolId())) > 0;
                    return new ImportCandidate(parsed.protocolId(), parsed.legislativePeriod(), parsed.sessionNumber(), link, exists);
                } catch (IllegalArgumentException ex) {
                    return null;
                }
            }).filter(candidate -> candidate != null).collect(Collectors.toList());
        } catch (IOException e) {
            LOGGER.error("Could not preview import candidates", e);
            return List.of();
        }
    }

    /**
     * Imports exactly one protocol by protocol id.
     */
    public ImportSummary importSingleProtocol(String protocolId, boolean forceReimportExisting) {
        try {
            List<String> xmlLinks = downloader.fetchProtocolXmlLinks();
            for (String xmlLink : xmlLinks) {
                ProtocolIdParser.ParsedProtocolId parsed;
                try {
                    parsed = ProtocolIdParser.parse(xmlLink);
                } catch (IllegalArgumentException ex) {
                    continue;
                }

                if (!parsed.protocolId().equals(protocolId)) {
                    continue;
                }

                ImportOptions options = new ImportOptions(parsed.legislativePeriod(), 1, forceReimportExisting);
                return importProtocolsWithFixedLinks(options, List.of(xmlLink));
            }
            return new ImportSummary(0, 0, 0, 0, 0, 0, 0, 0, 0);
        } catch (IOException e) {
            LOGGER.error("Could not import single protocol {}", protocolId, e);
            return new ImportSummary(0, 0, 0, 0, 0, 0, 0, 0, 0);
        }
    }

    /**
     * Imports protocols according to the provided options.
     */
    public ImportSummary importProtocols(ImportOptions options) {
        try {
            List<String> xmlLinks = filterLinks(downloader.fetchProtocolXmlLinks(), options);
            return importProtocolsWithFixedLinks(options, xmlLinks);
        } catch (IOException e) {
            LOGGER.error("Protocol import failed", e);
            return new ImportSummary(0, 0, 0, 0, 0, 0, 0, 0, 0);
        }
    }

    private ImportSummary importProtocolsWithFixedLinks(ImportOptions options, List<String> xmlLinks) {
        int importedProtocols = 0;
        int upsertedSessions = 0;
        int upsertedSpeeches = 0;
        int upsertedDeputies = 0;
        int upsertedVideos = 0;
        int enrichedDeputyImages = 0;
        int skippedInvalidSpeeches = 0;
        int skippedInvalidDeputies = 0;
        int skippedInvalidVideos = 0;

        for (String xmlLink : xmlLinks) {
            ProtocolIdParser.ParsedProtocolId parsedId;
            try {
                parsedId = ProtocolIdParser.parse(xmlLink);
            } catch (IllegalArgumentException ex) {
                LOGGER.debug("Skipping URL without parseable protocol id: {}", xmlLink);
                continue;
            }

            boolean exists = protocolDatabase.count("protocols", new Document("id", parsedId.protocolId())) > 0;
            if (exists && !options.forceReimportExisting()) {
                continue;
            }

            String xml;
            try {
                xml = downloader.downloadXml(xmlLink);
            } catch (IOException e) {
                LOGGER.error("Failed to download xml for {}", xmlLink, e);
                continue;
            }
            ProtocolDocument protocol = new ProtocolDocument();
            protocol.setId(parsedId.protocolId());
            protocol.setLegislativePeriod(parsedId.legislativePeriod());
            protocol.setSessionNumber(parsedId.sessionNumber());
            protocol.setSourceUrl(xmlLink);
            protocol.setRawXml(xml);
            protocol.setImportedAt(Instant.now());
            protocolDatabase.replaceById("protocols", protocol.getId(), protocol);
            importedProtocols++;

            XmlProtocolParser.ParsedProtocol parsedProtocol = parser.parse(
                    parsedId.protocolId(),
                    parsedId.legislativePeriod(),
                    xml
            );
            ValidationResult validationResult = validateParsedProtocol(parsedProtocol, parsedId.protocolId());

            sessionDatabase.replaceById("sessions", validationResult.session().getId(), validationResult.session());
            upsertedSessions++;

            for (Speech speech : validationResult.speeches()) {
                speechDatabase.replaceById("speeches", speech.getId(), speech);
                upsertedSpeeches++;
            }
            skippedInvalidSpeeches += validationResult.invalidSpeechCount();

            for (Deputy deputy : validationResult.deputies()) {
                deputyImageEnrichmentService.enrichWithProfileImage(deputy);
                for (ImageMetadata image : deputy.getImages()) {
                    mediaAssetDownloadService.downloadDeputyImage(image, deputy.getId());
                    enrichedDeputyImages++;
                }

                deputyDatabase.replaceById("deputies", deputy.getId(), deputy);
                upsertedDeputies++;
            }
            skippedInvalidDeputies += validationResult.invalidDeputyCount();

            for (SpeechVideo speechVideo : validationResult.videos()) {
                mediaAssetDownloadService.downloadSpeechVideo(speechVideo);
                speechVideoDatabase.replaceById("speech_videos", speechVideo.getId(), speechVideo);
                upsertedVideos++;
            }
            skippedInvalidVideos += validationResult.invalidVideoCount();
        }

        return new ImportSummary(
                importedProtocols,
                upsertedSessions,
                upsertedSpeeches,
                upsertedDeputies,
                upsertedVideos,
                enrichedDeputyImages,
                skippedInvalidSpeeches,
                skippedInvalidDeputies,
                skippedInvalidVideos
        );
    }

    private ValidationResult validateParsedProtocol(XmlProtocolParser.ParsedProtocol parsedProtocol, String protocolId) {
        ProtocolSession session = parsedProtocol.session();
        if (session.getId() == null || session.getId().isBlank()) {
            session.setId("session-" + protocolId);
        }
        if (session.getProtocolId() == null || session.getProtocolId().isBlank()) {
            session.setProtocolId(protocolId);
        }

        List<Speech> validSpeeches = parsedProtocol.speeches().stream()
                .filter(speech -> speech != null && speech.getId() != null && !speech.getId().isBlank())
                .peek(speech -> {
                    if (speech.getProtocolId() == null || speech.getProtocolId().isBlank()) {
                        speech.setProtocolId(protocolId);
                    }
                    if (speech.getSessionId() == null || speech.getSessionId().isBlank()) {
                        speech.setSessionId(session.getId());
                    }
                    if (speech.getText() == null) {
                        speech.setText("");
                    }
                })
                .collect(Collectors.toList());
        int invalidSpeechCount = parsedProtocol.speeches().size() - validSpeeches.size();

        List<Deputy> validDeputies = parsedProtocol.deputies().stream()
                .filter(deputy -> deputy != null && deputy.getId() != null && !deputy.getId().isBlank())
                .collect(Collectors.toList());
        int invalidDeputyCount = parsedProtocol.deputies().size() - validDeputies.size();

        Set<String> validSpeechIds = new HashSet<>();
        for (Speech speech : validSpeeches) {
            validSpeechIds.add(speech.getId());
        }
        List<SpeechVideo> validVideos = parsedProtocol.videos().stream()
                .filter(video -> video != null
                        && video.getId() != null
                        && !video.getId().isBlank()
                        && video.getSpeechId() != null
                        && validSpeechIds.contains(video.getSpeechId())
                        && video.getSourceUrl() != null
                        && !video.getSourceUrl().isBlank())
                .collect(Collectors.toList());
        int invalidVideoCount = parsedProtocol.videos().size() - validVideos.size();

        return new ValidationResult(
                session,
                validSpeeches,
                validDeputies,
                validVideos,
                invalidSpeechCount,
                invalidDeputyCount,
                invalidVideoCount
        );
    }

    private List<String> filterLinks(List<String> xmlLinks, ImportOptions options) {
        List<String> filtered = xmlLinks.stream()
                .filter(link -> {
                    if (options.legislativePeriodFilter() == null) {
                        return true;
                    }
                    try {
                        ProtocolIdParser.ParsedProtocolId id = ProtocolIdParser.parse(link);
                        return id.legislativePeriod() == options.legislativePeriodFilter();
                    } catch (IllegalArgumentException ex) {
                        return false;
                    }
                })
                .sorted(Comparator.naturalOrder())
                .collect(Collectors.toList());

        if (options.maxProtocols() > 0 && filtered.size() > options.maxProtocols()) {
            return filtered.subList(0, options.maxProtocols());
        }
        return filtered;
    }

    /**
     * Import run summary counters.
     */
    public record ImportSummary(
            int importedProtocols,
            int upsertedSessions,
            int upsertedSpeeches,
            int upsertedDeputies,
            int upsertedVideos,
            int enrichedDeputyImages,
            int skippedInvalidSpeeches,
            int skippedInvalidDeputies,
            int skippedInvalidVideos
    ) {
    }

    /**
     * Import options controlling period filter, maximum count, and forced reimport behavior.
     */
    public record ImportOptions(Integer legislativePeriodFilter, int maxProtocols, boolean forceReimportExisting) {
        /**
         * Default import options (all periods, unlimited count, no forced reimport).
         */
        public static ImportOptions defaultOptions() {
            return new ImportOptions(null, 0, false);
        }
    }

    /**
     * Preview row for one importable protocol source.
     */
    public record ImportCandidate(
            String protocolId,
            int legislativePeriod,
            int sessionNumber,
            String sourceUrl,
            boolean alreadyImported
    ) {
    }

    private record ValidationResult(
            ProtocolSession session,
            List<Speech> speeches,
            List<Deputy> deputies,
            List<SpeechVideo> videos,
            int invalidSpeechCount,
            int invalidDeputyCount,
            int invalidVideoCount
    ) {
    }
}
