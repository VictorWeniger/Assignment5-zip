package de.ppr.mpe.service.nlp;

import de.ppr.mpe.model.Speech;

/**
 * NLP engine contract for speech annotation providers.
 */
public interface NlpEngine {
    /**
     * Stable engine name used in metadata/logging.
     */
    String name();

    /**
     * Whether the engine can currently be used.
     */
    boolean isAvailable();

    /**
     * Annotates the given speech in-place.
     */
    void annotate(Speech speech);
}
