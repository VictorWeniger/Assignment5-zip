package de.ppr.mpe.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses protocol metadata from Bundestag XML file URLs.
 */
public final class ProtocolIdParser {
    private static final Pattern PROTOCOL_PATTERN = Pattern.compile("(\\d{2})(\\d{3})\\.xml$");

    private ProtocolIdParser() {
    }

    /**
     * Parses protocol id, legislative period, and session number from an XML URL.
     */
    public static ParsedProtocolId parse(String xmlUrl) {
        Matcher matcher = PROTOCOL_PATTERN.matcher(xmlUrl);
        if (!matcher.find()) {
            throw new IllegalArgumentException("Could not parse legislative period/session from URL: " + xmlUrl);
        }

        int legislativePeriod = Integer.parseInt(matcher.group(1));
        int sessionNumber = Integer.parseInt(matcher.group(2));
        String protocolId = legislativePeriod + "-" + sessionNumber;
        return new ParsedProtocolId(protocolId, legislativePeriod, sessionNumber);
    }

    /**
     * Parsed protocol identifier components.
     */
    public record ParsedProtocolId(String protocolId, int legislativePeriod, int sessionNumber) {
    }
}
