package de.ppr.mpe.service;

import de.ppr.mpe.model.Comment;
import de.ppr.mpe.model.Deputy;
import de.ppr.mpe.model.ParliamentaryGroup;
import de.ppr.mpe.model.ProtocolSession;
import de.ppr.mpe.model.Speech;
import de.ppr.mpe.model.SpeechVideo;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Parses Bundestag protocol XML into session, speech, deputy, comment, and video domain objects.
 */
public class XmlProtocolParser {
    /**
     * Parses one protocol XML payload.
     */
    public ParsedProtocol parse(String protocolId, int legislativePeriod, String xml) {
        Document doc = Jsoup.parse(xml, "", Parser.xmlParser());
        ProtocolSession session = new ProtocolSession();
        session.setId("session-" + protocolId);
        session.setProtocolId(protocolId);
        session.setLegislativePeriod(legislativePeriod);
        session.setSessionNumber(parseInt(findFirstText(doc, "sitzungsnr", "sitzungsnummer"), 0));
        session.setSessionDate(parseDate(findFirstText(doc, "sitzungsdatum", "datum")));

        extractAgenda(doc, session);

        Map<String, Deputy> deputyById = new LinkedHashMap<>();
        List<SpeechVideo> videos = new ArrayList<>();
        List<Speech> speeches = extractSpeeches(
                doc,
                protocolId,
                session.getId(),
                session.getSessionDate(),
                deputyById,
                videos
        );
        for (Speech speech : speeches) {
            session.getSpeechIds().add(speech.getId());
        }

        return new ParsedProtocol(session, speeches, new ArrayList<>(deputyById.values()), videos);
    }

    private void extractAgenda(Document doc, ProtocolSession session) {
        Elements tops = doc.select("tagesordnungspunkt");
        for (Element top : tops) {
            String label = textOrFallback(top.selectFirst("titel"), top.selectFirst("toptext"), top);
            if (!label.isBlank()) {
                session.getAgenda().add(label);
            }
        }
    }

    private List<Speech> extractSpeeches(
            Document doc,
            String protocolId,
            String sessionId,
            LocalDate sessionDate,
            Map<String, Deputy> deputyById,
            List<SpeechVideo> videos
    ) {
        List<Speech> result = new ArrayList<>();
        Elements redeElements = doc.select("rede");

        int index = 0;
        for (Element rede : redeElements) {
            Speech speech = new Speech();
            speech.setId(resolveSpeechId(rede, protocolId, ++index));
            speech.setProtocolId(protocolId);
            speech.setSessionId(sessionId);
            speech.setAgendaItem(parseAgendaItem(rede));
            speech.setStartedAt(parseSpeechStart(rede, sessionDate));
            speech.setEndedAt(parseSpeechEnd(rede, sessionDate));

            Deputy speaker = parseSpeaker(rede, protocolId, index);
            speech.setSpeaker(speaker);
            deputyById.putIfAbsent(speaker.getId(), speaker);

            speech.setText(extractSpeechText(rede));
            parseComments(rede, speech);
            SpeechVideo video = parseSpeechVideo(rede, speech, protocolId);
            if (video != null) {
                videos.add(video);
            }
            result.add(speech);
        }

        return result;
    }

    private Deputy parseSpeaker(Element rede, String protocolId, int index) {
        Deputy speaker = new Deputy();
        Element redner = rede.selectFirst("redner");
        String speakerId = firstNonBlank(
                redner == null ? "" : redner.attr("id"),
                clean(rede.select("redner > id").text()),
                clean(rede.select("redner id").text())
        );
        if (speakerId.isBlank()) {
            speakerId = "deputy-" + protocolId + "-" + index;
        }
        speaker.setId(speakerId);

        speaker.setTitle(firstNonBlank(
                clean(rede.select("redner titel").text()),
                redner == null ? "" : clean(redner.attr("titel"))
        ));
        speaker.setFirstName(firstNonBlank(
                clean(rede.select("redner vorname").text()),
                redner == null ? "" : clean(redner.attr("vorname"))
        ));
        speaker.setLastName(firstNonBlank(
                clean(rede.select("redner nachname").text()),
                redner == null ? "" : clean(redner.attr("nachname"))
        ));

        if (speaker.getFirstName() == null || speaker.getFirstName().isBlank()) {
            String name = firstNonBlank(
                    clean(rede.select("redner name").text()),
                    redner == null ? "" : clean(redner.attr("name"))
            );
            String[] parts = name.split("\\s+", 2);
            if (parts.length > 0) {
                speaker.setFirstName(parts[0]);
            }
            if (parts.length > 1) {
                speaker.setLastName(parts[1]);
            }
        }

        String factionText = clean(rede.select("redner fraktion").text());
        if (factionText.isBlank()) {
            factionText = firstNonBlank(
                    clean(rede.select("fraktion").text()),
                    redner == null ? "" : clean(redner.attr("fraktion")),
                    redner == null ? "" : clean(redner.attr("fraktion-kurz"))
            );
        }
        if (!factionText.isBlank()) {
            ParliamentaryGroup group = new ParliamentaryGroup();
            group.setId(toFactionId(factionText));
            group.setShortName(factionText);
            group.setDisplayName(factionText);
            speaker.setParliamentaryGroup(group);
        }

        return speaker;
    }

    private SpeechVideo parseSpeechVideo(Element redeElement, Speech speech, String protocolId) {
        String sourceUrl = firstNonBlank(
                redeElement.attr("video-url"),
                redeElement.attr("videourl"),
                redeElement.attr("mediathek-url"),
                redeElement.attr("video"),
                redeElement.select("video url").text(),
                redeElement.select("video-url").text(),
                redeElement.select("mediathek url").text(),
                redeElement.select("mediathek-url").text(),
                redeElement.select("media url").text(),
                redeElement.select("url").text()
        );
        if (sourceUrl.isBlank()) {
            String videoId = firstNonBlank(
                    redeElement.attr("videoid"),
                    redeElement.attr("video-id"),
                    redeElement.select("video-id").text(),
                    redeElement.select("videoid").text()
            );
            if (!videoId.isBlank()) {
                sourceUrl = "https://www.bundestag.de/mediathek?videoid=" + videoId;
            }
        }

        if (sourceUrl.isBlank()) {
            return null;
        }

        SpeechVideo video = new SpeechVideo();
        video.setId("video-" + protocolId + "-" + speech.getId());
        video.setSpeechId(speech.getId());
        video.setSourceUrl(sourceUrl);
        video.setDurationSeconds(0);
        return video;
    }

    private void parseComments(Element rede, Speech speech) {
        int idx = 0;
        int scanOffset = 0;
        for (Element c : rede.select("kommentar, interjection, zwischenruf")) {
            String text = clean(c.text());
            if (text.isBlank()) {
                continue;
            }

            Comment comment = new Comment();
            comment.setId(speech.getId() + "-comment-" + (++idx));
            comment.setSpeechId(speech.getId());
            comment.setText(text);
            if (speech.getText() == null) {
                comment.setSpeechOffset(0);
            } else {
                int found = speech.getText().indexOf(text, scanOffset);
                if (found < 0) {
                    found = speech.getText().indexOf(text);
                }
                comment.setSpeechOffset(Math.max(0, found));
                if (found >= 0) {
                    scanOffset = found + text.length();
                }
            }

            String author = clean(c.attr("redner"));
            if (author.isBlank()) {
                author = firstNonBlank(
                        clean(c.select("redner").text()),
                        clean(c.attr("urheber")),
                        clean(c.select("name").text())
                );
            }
            comment.setAuthorName(author);

            String faction = clean(c.attr("fraktion"));
            if (faction.isBlank()) {
                faction = clean(c.select("fraktion").text());
            }
            comment.setAuthorFaction(faction);

            speech.getComments().add(comment);
        }
    }

    private int parseAgendaItem(Element rede) {
        String top = firstNonBlank(
                rede.attr("top-id"),
                rede.attr("tagesordnungspunkt"),
                rede.attr("top"),
                rede.select("top-id").text()
        );
        if (top == null || top.isBlank()) {
            top = "";
        }
        return parseInt(top.replaceAll("[^0-9]", ""), 0);
    }

    private String extractSpeechText(Element rede) {
        StringBuilder builder = new StringBuilder();
        for (Element p : rede.select("p")) {
            String text = clean(p.text());
            if (!text.isBlank()) {
                if (!builder.isEmpty()) {
                    builder.append('\n');
                }
                builder.append(text);
            }
        }

        if (builder.isEmpty()) {
            builder.append(clean(rede.text()));
        }
        return builder.toString();
    }

    private Instant parseSpeechStart(Element rede, LocalDate sessionDate) {
        String raw = firstNonBlank(
                rede.attr("start"),
                rede.attr("beginn"),
                rede.attr("beginn-uhrzeit"),
                rede.select("beginn").text(),
                rede.select("start").text()
        );
        return parseInstant(raw, sessionDate);
    }

    private Instant parseSpeechEnd(Element rede, LocalDate sessionDate) {
        String raw = firstNonBlank(
                rede.attr("ende"),
                rede.attr("ende-uhrzeit"),
                rede.select("ende").text(),
                rede.select("end").text()
        );
        return parseInstant(raw, sessionDate);
    }

    private String resolveSpeechId(Element rede, String protocolId, int index) {
        String xmlId = rede.attr("id");
        if (!xmlId.isBlank()) {
            return xmlId;
        }

        String externalId = rede.select("rede-id").text();
        if (!externalId.isBlank()) {
            return externalId;
        }

        return "speech-" + protocolId + "-" + index + "-" + UUID.randomUUID();
    }

    private String findFirstText(Document doc, String... names) {
        for (String name : names) {
            Element element = doc.selectFirst(name);
            if (element != null) {
                String text = clean(element.text());
                if (!text.isBlank()) {
                    return text;
                }
            }
        }
        return "";
    }

    private String textOrFallback(Element preferred, Element alternative, Element fallback) {
        if (preferred != null) {
            String value = clean(preferred.text());
            if (!value.isBlank()) {
                return value;
            }
        }

        if (alternative != null) {
            String value = clean(alternative.text());
            if (!value.isBlank()) {
                return value;
            }
        }

        return clean(fallback.text());
    }

    private String clean(String value) {
        if (value == null) {
            return "";
        }
        return value.replace('\u00A0', ' ').trim();
    }

    private String firstNonBlank(String... values) {
        for (String value : values) {
            String cleaned = clean(value);
            if (!cleaned.isBlank()) {
                return cleaned;
            }
        }
        return "";
    }

    private String toFactionId(String factionName) {
        return factionName.toLowerCase().replaceAll("[^a-z0-9]+", "-").replaceAll("(^-|-$)", "");
    }

    private LocalDate parseDate(String raw) {
        String normalized = clean(raw).replace('.', '-');
        if (normalized.matches("\\d{4}-\\d{2}-\\d{2}")) {
            return LocalDate.parse(normalized);
        }

        if (normalized.matches("\\d{2}-\\d{2}-\\d{4}")) {
            String[] parts = normalized.split("-");
            return LocalDate.of(parseInt(parts[2], 1970), parseInt(parts[1], 1), parseInt(parts[0], 1));
        }

        return null;
    }

    private Instant parseInstant(String raw, LocalDate sessionDate) {
        String normalized = clean(raw);
        if (normalized.isBlank()) {
            return null;
        }

        // Full timestamp
        try {
            return Instant.parse(normalized);
        } catch (Exception ignored) {
        }

        // HH:mm(:ss) on session day
        if (sessionDate != null && normalized.matches("\\d{1,2}:\\d{2}(:\\d{2})?")) {
            String padded = normalized.length() == 5 ? normalized + ":00" : normalized;
            LocalTime localTime = LocalTime.parse(padded);
            return LocalDateTime.of(sessionDate, localTime)
                    .atZone(ZoneId.of("Europe/Berlin"))
                    .toInstant();
        }

        return null;
    }

    private int parseInt(String value, int fallback) {
        try {
            if (value == null) {
                return fallback;
            }
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    /**
     * Parsed protocol container.
     */
    public record ParsedProtocol(
            ProtocolSession session,
            List<Speech> speeches,
            List<Deputy> deputies,
            List<SpeechVideo> videos
    ) {
    }
}
