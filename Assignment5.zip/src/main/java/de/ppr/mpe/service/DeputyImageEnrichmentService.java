package de.ppr.mpe.service;

import de.ppr.mpe.model.Deputy;
import de.ppr.mpe.model.ImageMetadata;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;

/**
 * Best-effort enrichment service that attaches profile image metadata to deputies.
 */
public class DeputyImageEnrichmentService {
    private static final String IMAGE_DB_SEARCH = "https://bilddatenbank.bundestag.de/search/picture-result";

    /**
     * Attempts to enrich a deputy with one profile image URL.
     */
    public void enrichWithProfileImage(Deputy deputy) {
        if (deputy == null || deputy.getId() == null || deputy.getId().isBlank()) {
            return;
        }
        if (!deputy.getImages().isEmpty()) {
            return;
        }

        String nameQuery = (safe(deputy.getFirstName()) + " " + safe(deputy.getLastName())).trim();
        if (nameQuery.isBlank()) {
            return;
        }

        try {
            Document page = Jsoup.connect(IMAGE_DB_SEARCH)
                    .data("q", nameQuery)
                    .get();

            Element image = page.selectFirst("img[src]");
            if (image == null) {
                return;
            }

            String source = image.absUrl("src");
            if (source.isBlank()) {
                return;
            }

            ImageMetadata metadata = new ImageMetadata();
            metadata.setSourceUrl(source);
            metadata.setMimeType(inferMimeType(source));
            deputy.getImages().add(metadata);
        } catch (IOException ignored) {
            // Best-effort enrichment should never fail the full import.
        }
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private String inferMimeType(String url) {
        String lower = url.toLowerCase();
        if (lower.endsWith(".png")) {
            return "image/png";
        }
        if (lower.endsWith(".webp")) {
            return "image/webp";
        }
        return "image/jpeg";
    }
}
