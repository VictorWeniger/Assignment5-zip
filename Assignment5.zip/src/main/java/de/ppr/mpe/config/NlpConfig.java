package de.ppr.mpe.config;

/**
 * Runtime configuration for NLP engine selection and DUUI endpoint access.
 */
public class NlpConfig {
    /**
     * NLP engine operating mode.
     */
    public enum EngineMode {
        LOCAL,
        DUUI,
        AUTO
    }

    private final EngineMode engineMode;
    private final String duuiEndpoint;
    private final String duuiAuthToken;
    private final int duuiTimeoutSeconds;

    /**
     * Creates a new NLP configuration object.
     */
    public NlpConfig(EngineMode engineMode, String duuiEndpoint, String duuiAuthToken, int duuiTimeoutSeconds) {
        this.engineMode = engineMode;
        this.duuiEndpoint = duuiEndpoint;
        this.duuiAuthToken = duuiAuthToken;
        this.duuiTimeoutSeconds = duuiTimeoutSeconds;
    }

    /**
     * Selected NLP engine mode.
     */
    public EngineMode engineMode() {
        return engineMode;
    }

    /**
     * DUUI endpoint URL.
     */
    public String duuiEndpoint() {
        return duuiEndpoint;
    }

    /**
     * DUUI bearer token.
     */
    public String duuiAuthToken() {
        return duuiAuthToken;
    }

    /**
     * DUUI HTTP timeout in seconds.
     */
    public int duuiTimeoutSeconds() {
        return duuiTimeoutSeconds;
    }

    /**
     * Whether a DUUI endpoint URL is configured.
     */
    public boolean hasDuuiEndpoint() {
        return duuiEndpoint != null && !duuiEndpoint.isBlank();
    }

    /**
     * Whether a DUUI authentication token is configured.
     */
    public boolean hasDuuiToken() {
        return duuiAuthToken != null && !duuiAuthToken.isBlank();
    }
}
