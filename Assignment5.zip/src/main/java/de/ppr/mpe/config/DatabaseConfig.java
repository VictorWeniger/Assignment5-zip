package de.ppr.mpe.config;

/**
 * MongoDB connection configuration.
 */
public class DatabaseConfig {
    private final String connectionString;
    private final String databaseName;

    /**
     * Creates a database config object.
     */
    public DatabaseConfig(String connectionString, String databaseName) {
        this.connectionString = connectionString;
        this.databaseName = databaseName;
    }

    /**
     * MongoDB connection URI.
     */
    public String connectionString() {
        return connectionString;
    }

    /**
     * Database name to use inside MongoDB.
     */
    public String databaseName() {
        return databaseName;
    }

    /**
     * Reads connection settings from environment variables.
     */
    public static DatabaseConfig fromEnvironment() {
        String uri = System.getenv().getOrDefault("MPE_MONGO_URI", "mongodb://localhost:27017");
        String db = System.getenv().getOrDefault("MPE_MONGO_DB", "multimodal_parliament_explorer");
        return new DatabaseConfig(uri, db);
    }
}
