package de.ppr.mpe.api;

import de.ppr.mpe.db.DatabaseHandler;
import de.ppr.mpe.model.Deputy;
import de.ppr.mpe.model.ProtocolDocument;
import de.ppr.mpe.model.ProtocolSession;
import de.ppr.mpe.model.Speech;
import de.ppr.mpe.model.SpeechVideo;
import io.javalin.Javalin;
import org.bson.Document;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

/**
 * Registers protocol, speech, deputy, video, topic, and aggregate stats read APIs.
 */
public final class ProtocolController {
    private static final int MAX_QUERY_LIMIT = 1000;

    private ProtocolController() {
    }

    /**
     * Registers all read-side protocol and speech exploration routes.
     */
    public static void register(
            Javalin app,
            DatabaseHandler<ProtocolDocument> protocolDatabase,
            DatabaseHandler<ProtocolSession> sessionDatabase,
            DatabaseHandler<Speech> speechDatabase,
            DatabaseHandler<Deputy> deputyDatabase,
            DatabaseHandler<SpeechVideo> speechVideoDatabase
    ) {
        app.get("/api/protocols", ctx -> {
            try {
                int limit = parseInt(ctx.queryParam("limit"), 50, "limit");
                boolean includeRaw = parseBoolean(ctx.queryParam("includeRaw"), false, "includeRaw");
                List<ProtocolDocument> protocols = protocolDatabase.find("protocols", new Document(), ProtocolDocument.class);
                if (includeRaw) {
                    ctx.json(protocols.stream().limit(limit).toList());
                    return;
                }
                ctx.json(protocols.stream().limit(limit).map(ProtocolSummary::from).toList());
            } catch (IllegalArgumentException ex) {
                ctx.status(400).json(new Document("error", ex.getMessage()));
            }
        });

        app.get("/api/protocols/{id}", ctx -> {
            String id = ctx.pathParam("id");
            Optional<ProtocolDocument> protocol = protocolDatabase.findById("protocols", id, ProtocolDocument.class);
            if (protocol.isEmpty()) {
                ctx.status(404).json(new Document("error", "protocol not found"));
                return;
            }
            boolean includeRaw;
            try {
                includeRaw = parseBoolean(ctx.queryParam("includeRaw"), false, "includeRaw");
            } catch (IllegalArgumentException ex) {
                ctx.status(400).json(new Document("error", ex.getMessage()));
                return;
            }
            if (includeRaw) {
                ctx.json(protocol.get());
                return;
            }
            ctx.json(ProtocolSummary.from(protocol.get()));
        });

        app.get("/api/sessions", ctx -> {
            Document filter = new Document();
            String protocolId = ctx.queryParam("protocolId");
            if (protocolId != null && !protocolId.isBlank()) {
                filter.append("protocolId", protocolId);
            }
            ctx.json(sessionDatabase.find("sessions", filter, ProtocolSession.class));
        });

        app.get("/api/speeches", ctx -> {
            try {
                String agendaItem = ctx.queryParam("agendaItem");
                Integer agendaItemValue = null;
                if (agendaItem != null && !agendaItem.isBlank()) {
                    agendaItemValue = parseInt(agendaItem, 0, "agendaItem");
                }
                Document filter = SpeechQueryFilterBuilder.build(
                        ctx.queryParam("protocolId"),
                        ctx.queryParam("protocolIds"),
                        ctx.queryParam("sessionId"),
                        ctx.queryParam("speakerId"),
                        ctx.queryParam("faction"),
                        ctx.queryParam("topic"),
                        agendaItemValue,
                        ctx.queryParam("matchMode")
                );
                Instant from = parseInstantNullable(ctx.queryParam("from"), "from");
                Instant to = parseInstantNullable(ctx.queryParam("to"), "to");

                int limit = parseInt(ctx.queryParam("limit"), 100, "limit");
                List<Speech> speeches = speechDatabase.find("speeches", filter, Speech.class);
                if (from != null || to != null) {
                    speeches = speeches.stream().filter(speech -> {
                        Instant startedAt = speech.getStartedAt();
                        if (startedAt == null) {
                            return false;
                        }
                        if (from != null && startedAt.isBefore(from)) {
                            return false;
                        }
                        if (to != null && startedAt.isAfter(to)) {
                            return false;
                        }
                        return true;
                    }).toList();
                }
                ctx.json(speeches.stream().limit(limit).toList());
            } catch (IllegalArgumentException ex) {
                ctx.status(400).json(new Document("error", ex.getMessage()));
            }
        });

        app.get("/api/speeches/search", ctx -> {
            String q = ctx.queryParam("q");
            int limit;
            try {
                limit = parseInt(ctx.queryParam("limit"), 100, "limit");
            } catch (IllegalArgumentException ex) {
                ctx.status(400).json(new Document("error", ex.getMessage()));
                return;
            }
            if (q == null || q.isBlank()) {
                ctx.status(400).json(new Document("error", "q is required"));
                return;
            }

            Document regex = new Document("$regex", q).append("$options", "i");
            Document filter = new Document("text", regex);
            List<Speech> speeches = speechDatabase.find("speeches", filter, Speech.class);
            ctx.json(speeches.stream().limit(limit).toList());
        });

        app.get("/api/speeches/{id}", ctx -> {
            String id = ctx.pathParam("id");
            Optional<Speech> speech = speechDatabase.findById("speeches", id, Speech.class);
            if (speech.isEmpty()) {
                ctx.status(404).json(new Document("error", "speech not found"));
                return;
            }
            ctx.json(speech.get());
        });

        app.get("/api/speeches/{id}/detail", ctx -> {
            String id = ctx.pathParam("id");
            Optional<Speech> speechOpt = speechDatabase.findById("speeches", id, Speech.class);
            if (speechOpt.isEmpty()) {
                ctx.status(404).json(new Document("error", "speech not found"));
                return;
            }

            Speech speech = speechOpt.get();
            Deputy speaker = null;
            if (speech.getSpeaker() != null && speech.getSpeaker().getId() != null && !speech.getSpeaker().getId().isBlank()) {
                speaker = deputyDatabase.findById("deputies", speech.getSpeaker().getId(), Deputy.class).orElse(speech.getSpeaker());
            }

            Document videoFilter = new Document("speechId", speech.getId());
            SpeechVideo video = speechVideoDatabase.find("speech_videos", videoFilter, SpeechVideo.class).stream().findFirst().orElse(null);
            ctx.json(new SpeechDetailResponse(speech, speaker, video));
        });

        app.get("/api/deputies", ctx -> {
            try {
                int limit = parseInt(ctx.queryParam("limit"), 200, "limit");
                List<Deputy> deputies = deputyDatabase.find("deputies", new Document(), Deputy.class);
                ctx.json(deputies.stream().limit(limit).toList());
            } catch (IllegalArgumentException ex) {
                ctx.status(400).json(new Document("error", ex.getMessage()));
            }
        });

        app.get("/api/deputies/{id}", ctx -> {
            String id = ctx.pathParam("id");
            Optional<Deputy> deputy = deputyDatabase.findById("deputies", id, Deputy.class);
            if (deputy.isEmpty()) {
                ctx.status(404).json(new Document("error", "deputy not found"));
                return;
            }
            ctx.json(deputy.get());
        });

        app.get("/api/videos", ctx -> {
            try {
                Document filter = new Document();
                appendFilter(filter, "speechId", ctx.queryParam("speechId"));
                int limit = parseInt(ctx.queryParam("limit"), 200, "limit");
                List<SpeechVideo> videos = speechVideoDatabase.find("speech_videos", filter, SpeechVideo.class);
                ctx.json(videos.stream().limit(limit).toList());
            } catch (IllegalArgumentException ex) {
                ctx.status(400).json(new Document("error", ex.getMessage()));
            }
        });

        app.get("/api/videos/{id}", ctx -> {
            String id = ctx.pathParam("id");
            Optional<SpeechVideo> video = speechVideoDatabase.findById("speech_videos", id, SpeechVideo.class);
            if (video.isEmpty()) {
                ctx.status(404).json(new Document("error", "video not found"));
                return;
            }
            ctx.json(video.get());
        });

        app.get("/api/topics", ctx -> {
            int limit;
            try {
                limit = parseInt(ctx.queryParam("limit"), 100, "limit");
            } catch (IllegalArgumentException ex) {
                ctx.status(400).json(new Document("error", ex.getMessage()));
                return;
            }

            List<Document> pipeline = List.of(
                    new Document("$project", new Document("topics", new Document("$ifNull", List.of("$nlp.topics", "$topics")))),
                    new Document("$unwind", "$topics"),
                    new Document("$project", new Document("label", new Document("$ifNull", List.of("$topics.label", "$topics.topic")))),
                    new Document("$match", new Document("label", new Document("$ne", null))),
                    new Document("$group", new Document("_id", "$label").append("count", new Document("$sum", 1))),
                    new Document("$sort", new Document("count", -1)),
                    new Document("$limit", limit)
            );
            ctx.json(speechDatabase.aggregate("speeches", pipeline));
        });

        app.get("/api/stats", ctx -> ctx.json(new Document()
                .append("protocols", protocolDatabase.count("protocols", new Document()))
                .append("sessions", sessionDatabase.count("sessions", new Document()))
                .append("speeches", speechDatabase.count("speeches", new Document()))
                .append("deputies", deputyDatabase.count("deputies", new Document()))
                .append("videos", speechVideoDatabase.count("speech_videos", new Document()))));
    }

    /**
     * Appends a field filter if the provided value is not blank.
     */
    private static void appendFilter(Document filter, String field, String value) {
        if (value != null && !value.isBlank()) {
            filter.append(field, value);
        }
    }

    /**
     * Parses a non-negative integer and enforces max limit constraints for limit parameters.
     */
    private static int parseInt(String input, int fallback, String name) {
        try {
            if (input == null || input.isBlank()) {
                return fallback;
            }
            int parsed = Integer.parseInt(input);
            if (parsed < 0) {
                throw new IllegalArgumentException(name + " must be >= 0");
            }
            if ("limit".equals(name) && parsed > MAX_QUERY_LIMIT) {
                throw new IllegalArgumentException("limit must be <= " + MAX_QUERY_LIMIT);
            }
            return parsed;
        } catch (NumberFormatException ignored) {
            throw new IllegalArgumentException(name + " must be an integer");
        }
    }

    /**
     * Parses a boolean query parameter.
     */
    private static boolean parseBoolean(String input, boolean fallback, String name) {
        if (input == null || input.isBlank()) {
            return fallback;
        }
        if ("true".equalsIgnoreCase(input)) {
            return true;
        }
        if ("false".equalsIgnoreCase(input)) {
            return false;
        }
        throw new IllegalArgumentException(name + " must be true or false");
    }

    /**
     * Parses an optional ISO-8601 instant query parameter.
     */
    private static Instant parseInstantNullable(String input, String name) {
        if (input == null || input.isBlank()) {
            return null;
        }
        try {
            return Instant.parse(input);
        } catch (Exception ignored) {
            throw new IllegalArgumentException(name + " must be an ISO-8601 instant");
        }
    }
}
