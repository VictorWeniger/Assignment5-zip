package de.ppr.mpe.api;

import de.ppr.mpe.model.Deputy;
import de.ppr.mpe.model.Speech;
import de.ppr.mpe.model.SpeechVideo;

/**
 * Combined response payload for speech detail page data.
 */
public record SpeechDetailResponse(
        Speech speech,
        Deputy speaker,
        SpeechVideo video
) {
}
