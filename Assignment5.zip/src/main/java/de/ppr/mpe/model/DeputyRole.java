package de.ppr.mpe.model;

/**
 * Functional role of a deputy in a parliamentary context.
 */
public enum DeputyRole {
    DEPUTY,
    PRESIDENT,
    MINISTER,
    SECRETARY,
    GUEST
}
