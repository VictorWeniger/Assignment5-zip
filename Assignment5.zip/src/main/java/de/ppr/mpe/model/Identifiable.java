package de.ppr.mpe.model;

/**
 * Marker interface for entities with a stable string id.
 */
public interface Identifiable {
    /**
     * Returns the entity identifier.
     */
    String getId();
}
